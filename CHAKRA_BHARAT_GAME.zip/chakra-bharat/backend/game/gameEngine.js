/**
 * CHAKRA-BHARAT: Master Game Engine
 * The central authoritative source of truth.
 * Coordinates all managers: Players, Resources, Buildings, Turns, Events, Consequences, Trade, and Scoring.
 */

const path = require('path');
const Player = require('./player');
const ResourceManager = require('./resources');
const BuildingManager = require('./buildings');
const { EventManager, ConsequenceEngine } = require('./events');
const TurnManager = require('./turns');
const TradeManager = require('./trade');
const ScoringManager = require('./scoring');
const { explainGame } = require('./explainability');

class GameEngine {
  constructor() {
    this.buildingManager = new BuildingManager();
    this.eventManager = new EventManager();
    this.tradeManager = new TradeManager();

    // Load game modes
    const modesData = require(path.join(__dirname, '../../data/gameModes.json'));
    this.gameModes = modesData.modes;

    this.stateListeners = [];
    this.reset();
  }

  onStateChange(fn) {
    this.stateListeners.push(fn);
  }

  notifyStateChange(eventType = 'STATE_UPDATE', meta = {}) {
    const state = this.getState();
    for (const listener of this.stateListeners) {
      try {
        listener(eventType, state, meta);
      } catch (err) {
        console.error('[GameEngine] Error in state listener:', err);
      }
    }
  }

  reset() {
    this.gameId = `CB-${Date.now().toString(36).toUpperCase()}`;
    this.mode = 'basic';
    this.status = 'SETUP'; // 'SETUP', 'ACTIVE', 'EVENT', 'GAME_OVER'
    this.players = [];
    this.turnManager = null;
    this.currentEvent = null;
    this.lastConsequences = null;
    this.eventHistory = [];
    this.actionHistory = [];
    this.winner = null;
    this.rankings = null;
    this.heroExplanation = null;
    this.explainability = [];
  }

  createGame({ mode = 'basic', players = [] } = {}) {
    this.reset();
    const selectedMode = this.gameModes.find(m => m.id === mode) || this.gameModes[0];
    this.mode = selectedMode.id;

    const initialPlayers = players.length >= 2 ? players : [
      { id: 1, name: 'Player 1', civilizationName: 'Indus Builders' },
      { id: 2, name: 'Player 2', civilizationName: 'Vedic Pioneers' }
    ];

    this.players = initialPlayers.map((p, idx) => {
      return new Player({
        id: p.id || idx + 1,
        name: p.name || `Player ${idx + 1}`,
        civilizationName: p.civilizationName || `Civilization ${idx + 1}`,
        startingResources: selectedMode.startingResources,
        badge: p.badge
      });
    });

    this.turnManager = new TurnManager(selectedMode.rounds, this.players.length);
    this.status = 'ACTIVE';

    this.logAction(0, 'GAME_CREATED', {
      mode: this.mode,
      rounds: selectedMode.rounds,
      playerCount: this.players.length
    });

    this.notifyStateChange('GAME_CREATED');
    return this.getState();
  }

  getPlayer(playerId) {
    return this.players.find(p => p.id === parseInt(playerId, 10)) || null;
  }

  getActivePlayer() {
    if (!this.turnManager || this.players.length === 0) return null;
    return this.players[this.turnManager.currentPlayerIndex % this.players.length];
  }

  logAction(playerId, actionType, details = {}) {
    const entry = {
      id: `ACT-${Date.now().toString(36)}-${Math.random().toString(36).substr(2, 4)}`,
      round: this.turnManager ? this.turnManager.currentRound : 1,
      playerId,
      playerName: playerId ? (this.getPlayer(playerId)?.name || `Player ${playerId}`) : 'System',
      actionType,
      details,
      timestamp: new Date().toISOString()
    };
    this.actionHistory.unshift(entry);
    if (this.actionHistory.length > 50) this.actionHistory.pop();
    return entry;
  }

  /**
   * Primary action executor
   */
  executeAction(playerId, actionType, payload = {}) {
    if (this.status === 'GAME_OVER') {
      return { success: false, reason: 'Game has already concluded.' };
    }

    const player = this.getPlayer(playerId);
    if (!player) {
      return { success: false, reason: `Player ${playerId} not found.` };
    }

    const activePlayer = this.getActivePlayer();
    if (activePlayer && activePlayer.id !== player.id && actionType !== 'TRADE_ACCEPT' && actionType !== 'TRADE_REJECT') {
      return {
        success: false,
        reason: `Not ${player.name}'s turn. Current active player: ${activePlayer.name}.`
      };
    }

    let result = { success: false, reason: 'Unknown action' };

    switch (actionType) {
      case 'BUILD': {
        const buildingId = payload.buildingId || payload.item;
        result = this.buildingManager.build(player, buildingId, this.turnManager.currentRound);
        if (result.success) {
          player.checkAchievements();
          this.logAction(player.id, 'BUILD', {
            building: result.building.name,
            cost: result.costPaid
          });
          ScoringManager.calculatePlayerScore(player);
          this.notifyStateChange('BUILD_SUCCESS', { playerId: player.id, building: result.building });
        }
        break;
      }

      case 'COLLECT': {
        const yieldDelta = ResourceManager.collectTurnYield(player);
        player.stats.collections = (player.stats.collections || 0) + 1;
        result = { success: true, collected: yieldDelta, resources: { ...player.resources } };
        this.logAction(player.id, 'COLLECT', { yield: yieldDelta });
        ScoringManager.calculatePlayerScore(player);
        this.notifyStateChange('COLLECT_SUCCESS', { playerId: player.id, yield: yieldDelta });
        break;
      }

      case 'TRADE_PROPOSE': {
        const toPlayer = this.getPlayer(payload.toPlayerId);
        result = this.tradeManager.proposeTrade(player, toPlayer, payload.offer, payload.request);
        if (result.success) {
          this.logAction(player.id, 'TRADE_PROPOSE', {
            toPlayer: toPlayer.name,
            offer: payload.offer,
            request: payload.request
          });
          this.notifyStateChange('TRADE_PROPOSED', { trade: result.trade });
        }
        break;
      }

      case 'TRADE_ACCEPT': {
        result = this.tradeManager.acceptTrade(payload.tradeId, this.players);
        if (result.success) {
          this.logAction(player.id, 'TRADE_ACCEPT', { tradeId: payload.tradeId });
          this.players.forEach(p => ScoringManager.calculatePlayerScore(p));
          this.notifyStateChange('TRADE_ACCEPTED', { trade: result.trade });
        }
        break;
      }

      case 'TRADE_REJECT': {
        result = this.tradeManager.rejectTrade(payload.tradeId);
        if (result.success) {
          this.logAction(player.id, 'TRADE_REJECT', { tradeId: payload.tradeId });
          this.notifyStateChange('TRADE_REJECTED', { trade: result.trade });
        }
        break;
      }

      case 'CARAVAN_TRADE': {
        result = this.tradeManager.tradeWithCaravan(
          player,
          payload.giveResource,
          payload.getResource,
          payload.amount || 1
        );
        if (result.success) {
          this.logAction(player.id, 'CARAVAN_TRADE', {
            gave: result.deducted,
            gained: result.gained,
            marketPerk: result.hasMarketPerk
          });
          ScoringManager.calculatePlayerScore(player);
          this.notifyStateChange('CARAVAN_TRADE_SUCCESS', { playerId: player.id, result });
        }
        break;
      }

      case 'SPECIAL_ACTION': {
        // Annadanam food feast: costs 1 Food, grants +1 Water and +2 Culture
        const cost = { food: 1 };
        if (!ResourceManager.hasEnough(player.resources, cost)) {
          result = { success: false, reason: 'Need 1 Food to perform the Annadanam Community Food Feast.' };
        } else {
          ResourceManager.deduct(player.resources, cost);
          ResourceManager.add(player.resources, { water: 1 });
          player.stats.specialActions = (player.stats.specialActions || 0) + 1;
          player.scoreBreakdown.culturalDevelopment = (player.scoreBreakdown.culturalDevelopment || 0) + 2;
          this.logAction(player.id, 'SPECIAL_ACTION', { action: 'Annadanam Community Food Feast (+1 Water, +2 Culture)' });
          ScoringManager.calculatePlayerScore(player);
          this.notifyStateChange('SPECIAL_ACTION_SUCCESS', { playerId: player.id });
          result = { success: true, message: 'Annadanam Community Food Feast performed successfully.' };
        }
        break;
      }

      case 'END_TURN': {
        result = this.handleEndTurn();
        break;
      }

      default:
        result = { success: false, reason: `Unrecognized action type: ${actionType}` };
    }

    if (!result.success) {
      player.stats.failedActions = (player.stats.failedActions || 0) + 1;
      if (actionType.startsWith('TRADE')) {
        player.stats.failedTrades = (player.stats.failedTrades || 0) + 1;
      }
      if (actionType === 'BUILD') {
        player.stats.failedBuilds = (player.stats.failedBuilds || 0) + 1;
      }
      this.logAction(player.id, `FAILED_${actionType}`, {
        originalAction: actionType,
        reason: result.reason || 'Action rejected by game rules',
        payload
      });
      this.notifyStateChange('ACTION_REJECTED', { playerId: player.id, actionType, reason: result.reason });
    }

    return result;
  }

  /**
   * Handle turn ending and round advancement
   */
  handleEndTurn() {
    const activePlayer = this.getActivePlayer();
    activePlayer.stats.turnsEnded = (activePlayer.stats.turnsEnded || 0) + 1;
    this.logAction(activePlayer.id, 'END_TURN', { round: this.turnManager.currentRound });

    const turnInfo = this.turnManager.nextTurn();

    if (turnInfo.isGameOver) {
      return this.finishGame();
    }

    if (turnInfo.isEventDue) {
      // Trigger round event
      this.status = 'EVENT';
      const event = this.eventManager.drawRandomEvent();
      this.resolveEvent(event);
      return { success: true, phase: 'EVENT', event, turnInfo };
    }

    this.status = 'ACTIVE';
    this.notifyStateChange('TURN_CHANGED', { activePlayerId: this.getActivePlayer().id });
    return { success: true, turnInfo };
  }

  /**
   * Resolve an event across all players via ConsequenceEngine
   */
  resolveEvent(event) {
    this.currentEvent = event;
    const eventResult = this.eventManager.triggerEvent(event, this.players, {
      round: this.turnManager ? this.turnManager.currentRound : 1
    });

    this.lastConsequences = eventResult.playerResults;
    this.eventHistory.unshift(eventResult);

    // Update scores & achievements for all players
    this.players.forEach(p => {
      ScoringManager.calculatePlayerScore(p);
      p.checkAchievements();
    });

    this.logAction(0, 'EVENT_TRIGGERED', {
      event: event.title,
      category: event.category
    });

    this.notifyStateChange('EVENT_TRIGGERED', {
      event,
      consequences: this.lastConsequences
    });

    return eventResult;
  }

  dismissCurrentEvent() {
    this.currentEvent = null;
    this.lastConsequences = null;
    this.status = this.turnManager && this.turnManager.isGameComplete() ? 'GAME_OVER' : 'ACTIVE';
    this.notifyStateChange('EVENT_DISMISSED');
    return { success: true };
  }

  /**
   * Conclude game, calculate final scores, determine winner
   */
  finishGame() {
    this.status = 'GAME_OVER';
    const evaluation = ScoringManager.evaluateGame(this.players);
    this.winner = evaluation.winner;
    this.rankings = evaluation.rankings;
    this.explainability = explainGame(this.players, this.actionHistory, this.eventHistory);

    this.logAction(0, 'GAME_OVER', {
      winner: this.winner.name,
      score: this.winner.score,
      reason: evaluation.victoryReason
    });

    this.notifyStateChange('GAME_OVER', {
      winner: this.winner,
      rankings: this.rankings,
      victoryReason: evaluation.victoryReason
    });

    return {
      success: true,
      winner: this.winner,
      rankings: this.rankings,
      victoryReason: evaluation.victoryReason
    };
  }

  /**
   * Hardware command bridge (processes commands from real ESP32 or Virtual Pad)
   */
  handleHardwareCommand(cmd) {
    if (!cmd || !cmd.action) {
      return { success: false, reason: 'Invalid command packet' };
    }

    const playerId = cmd.player || (this.getActivePlayer() ? this.getActivePlayer().id : 1);

    if (cmd.action === 'BUILD') {
      let buildingId = cmd.item;
      if (cmd.uid) {
        const resolved = this.buildingManager.resolveRfidToBuilding(cmd.uid);
        if (resolved) buildingId = resolved.id;
      }
      return this.executeAction(playerId, 'BUILD', { buildingId });
    }

    if (cmd.action === 'BUTTON') {
      const button = (cmd.item || '').toUpperCase();
      if (button === 'CONFIRM') {
        if (this.currentEvent) {
          return this.dismissCurrentEvent();
        }
        return { success: true, message: 'CONFIRM_ACK' };
      }
      if (button === 'NEXT') {
        return this.executeAction(playerId, 'END_TURN');
      }
      if (button === 'EVENT') {
        const ev = this.eventManager.drawRandomEvent();
        this.resolveEvent(ev);
        return { success: true, event: ev.title };
      }
    }

    if (cmd.action === 'NEXT_TURN') {
      return this.executeAction(playerId, 'END_TURN');
    }

    return { success: false, reason: `Unsupported hardware action: ${cmd.action}` };
  }

  /**
   * Dedicated Quick Demo Walkthrough Runner
   * Demonstrates the hero loop in 4 precise steps:
   * 1. Start Demo Game (Player 1 & 2)
   * 2. Player 1 builds WATER SYSTEM (system records it)
   * 3. Trigger DROUGHT event
   * 4. Consequence Engine reveals 3 -> 1 Water mitigation + Hero Explanation
   */
  runDemoStep(stepNumber) {
    switch (stepNumber) {
      case 1: {
        // Reset and create demo game
        this.createGame({
          mode: 'demo',
          players: [
            { id: 1, name: 'Arjun (Hardware)', civilizationName: 'Indus Builders' },
            { id: 2, name: 'Vikram (Digital)', civilizationName: 'Vedic Pioneers' }
          ]
        });

        this.heroExplanation = {
          step: 1,
          title: 'STEP 1: CIVILIZATIONS INITIALIZED',
          message: 'Two civilizations begin with balanced resources (5 Food, 5 Water, 5 Materials, 5 Wealth). Player 1 is ready to deploy physical infrastructure.'
        };
        this.notifyStateChange('DEMO_STEP_1', this.heroExplanation);
        return { success: true, step: 1, state: this.getState() };
      }

      case 2: {
        // Player 1 physically builds WATER_SYSTEM
        const p1 = this.getPlayer(1);
        const buildResult = this.executeAction(1, 'BUILD', { buildingId: 'WATER_SYSTEM' });

        this.heroExplanation = {
          step: 2,
          title: 'STEP 2: PHYSICAL INFRASTRUCTURE RECORDED',
          message: 'Player 1 placed and scanned the WATER SYSTEM! The digital Game Engine registers traditional water storage and stepwells.',
          built: buildResult.success,
          player1Buildings: { ...p1.buildings }
        };
        this.notifyStateChange('DEMO_STEP_2', this.heroExplanation);
        return { success: true, step: 2, buildResult, state: this.getState() };
      }

      case 3: {
        // Trigger DROUGHT event
        const droughtEvent = this.eventManager.getEvent('DROUGHT');
        this.status = 'EVENT';
        const eventResult = this.resolveEvent(droughtEvent);

        this.heroExplanation = {
          step: 3,
          title: 'STEP 3: CLIMATIC CRISIS — SEVERE DROUGHT',
          message: 'The summer monsoon fails! The Consequence Engine evaluates the previous infrastructure of each civilization.'
        };
        this.notifyStateChange('DEMO_STEP_3', this.heroExplanation);
        return { success: true, step: 3, eventResult, state: this.getState() };
      }

      case 4: {
        // Hero Comparison & Explanation
        const p1 = this.getPlayer(1);
        const p2 = this.getPlayer(2);

        this.heroExplanation = {
          step: 4,
          title: 'HERO PROOF: PREVIOUS DECISIONS SHAPE FUTURE SURVIVAL',
          cause: 'Player 1 previously built traditional WATER SYSTEM infrastructure.',
          event: 'Severe Summer Drought strikes all territories.',
          p1Outcome: `Player 1 (Indus Builders) has WATER SYSTEM → Loss reduced to -1 Water (Water: ${p1.resources.water})`,
          p2Outcome: `Player 2 (Vedic Pioneers) NO Water System → Suffered full damage: -3 Water (Water: ${p2.resources.water})`,
          demoLesson: 'Physical infrastructure → Digital game state → Future consequence mitigation. The core innovation of CHAKRA-BHARAT is proven.'
        };

        this.notifyStateChange('DEMO_STEP_4', this.heroExplanation);
        return { success: true, step: 4, heroExplanation: this.heroExplanation, state: this.getState() };
      }

      default:
        return { success: false, reason: `Invalid demo step: ${stepNumber}` };
    }
  }

  getState() {
    const activePlayer = this.getActivePlayer();
    return {
      gameId: this.gameId,
      mode: this.mode,
      status: this.status,
      currentRound: this.turnManager ? this.turnManager.currentRound : 1,
      maxRounds: this.turnManager ? this.turnManager.maxRounds : 8,
      turnInRound: this.turnManager ? this.turnManager.turnInRound : 1,
      activePlayerId: activePlayer ? activePlayer.id : 1,
      players: this.players.map(p => p.toJSON()),
      currentEvent: this.currentEvent,
      lastConsequences: this.lastConsequences,
      actionHistory: this.actionHistory.slice(0, 20),
      eventHistory: this.eventHistory.slice(0, 10),
      winner: this.winner ? (typeof this.winner.toJSON === 'function' ? this.winner.toJSON() : this.winner) : null,
      rankings: this.rankings,
      explainability: this.explainability,
      heroExplanation: this.heroExplanation,
      buildingsCatalog: this.buildingManager.getAllBuildings()
    };
  }
}

module.exports = GameEngine;
