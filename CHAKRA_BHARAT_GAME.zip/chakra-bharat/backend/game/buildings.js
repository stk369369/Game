/**
 * CHAKRA-BHARAT: Building Manager
 * Manages the 4 core civilization structures:
 * - Farm (Agricultural development & Food)
 * - Water System (Stepwells/Baolis, drought & flood protection)
 * - Market (Trade guild, commerce & trade boom amplification)
 * - Fort (Defensive citadel & stockpile protection)
 */

const path = require('path');
const ResourceManager = require('./resources');

class BuildingManager {
  constructor(buildingsData) {
    if (buildingsData) {
      this.buildings = buildingsData.buildings;
      this.rfidMapping = buildingsData.rfidMapping || {};
    } else {
      const data = require(path.join(__dirname, '../../data/buildings.json'));
      this.buildings = data.buildings;
      this.rfidMapping = data.rfidMapping || {};
    }

    this.buildingMap = new Map();
    this.buildings.forEach(b => this.buildingMap.set(b.id, b));
  }

  getBuilding(buildingId) {
    if (!buildingId) return null;
    const normalized = buildingId.toUpperCase().replace(/\s+/g, '_');
    return this.buildingMap.get(normalized) || null;
  }

  resolveRfidToBuilding(uid) {
    if (!uid) return null;
    const mappedId = this.rfidMapping[uid] || this.rfidMapping[uid.toUpperCase()];
    if (mappedId) return this.getBuilding(mappedId);
    return this.getBuilding(uid);
  }

  getAllBuildings() {
    return this.buildings;
  }

  canBuild(player, buildingId) {
    const building = this.getBuilding(buildingId);
    if (!building) {
      return { canBuild: false, reason: `Unknown building ID: ${buildingId}` };
    }

    // Check if player already constructed this building
    if (player.buildings && player.buildings[building.id]) {
      return {
        canBuild: false,
        reason: `${building.name} has already been constructed by this civilization.`
      };
    }

    // Check resource affordability
    if (!ResourceManager.hasEnough(player.resources, building.cost)) {
      const missing = {};
      for (const [res, cost] of Object.entries(building.cost)) {
        const available = player.resources[res] || 0;
        if (available < cost) {
          missing[res] = cost - available;
        }
      }
      return {
        canBuild: false,
        reason: `Insufficient resources to construct ${building.name}.`,
        missing
      };
    }

    return { canBuild: true, building };
  }

  build(player, buildingId, round = 1) {
    const check = this.canBuild(player, buildingId);
    if (!check.canBuild) {
      return {
        success: false,
        reason: check.reason,
        missing: check.missing
      };
    }

    const building = check.building;

    // Deduct cost
    const deduction = ResourceManager.deduct(player.resources, building.cost);
    if (!deduction.success) {
      return { success: false, reason: 'Failed to deduct resources.' };
    }

    // Register building in player civilization
    player.buildings[building.id] = true;
    player.stats.buildingsBuilt = (player.stats.buildingsBuilt || 0) + 1;
    player.buildingHistory = player.buildingHistory || [];
    // Place the constructed building on the player's 2x3 quadrant.
    // This is authoritative state used by the merged CB board UI.
    player.board = player.board || { rows: 2, cols: 3, placements: [] };
    const occupied = new Set((player.board.placements || []).map(p => `${p.row}:${p.col}`));
    let boardPosition = null;
    for (let row = 0; row < player.board.rows && !boardPosition; row++) {
      for (let col = 0; col < player.board.cols; col++) {
        if (!occupied.has(`${row}:${col}`)) {
          boardPosition = { row, col };
          break;
        }
      }
    }
    if (boardPosition) {
      player.board.placements.push({
        buildingId: building.id,
        name: building.name,
        row: boardPosition.row,
        col: boardPosition.col,
        round,
        timestamp: new Date().toISOString()
      });
    }

    player.buildingHistory.push({
      buildingId: building.id,
      name: building.name,
      round,
      boardPosition,
      timestamp: new Date().toISOString()
    });

    return {
      success: true,
      building,
      costPaid: building.cost,
      boardPosition,
      remainingResources: { ...player.resources }
    };
  }
}

module.exports = BuildingManager;
