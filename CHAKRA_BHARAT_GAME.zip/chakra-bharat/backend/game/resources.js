/**
 * CHAKRA-BHARAT: Resource Manager
 * Manages the 4 core civilization resources:
 * - Food (sustenance, growth, agricultural strength)
 * - Water (survival, drought mitigation, stepwell conservation)
 * - Materials (timber, stone, physical infrastructure)
 * - Wealth (trade, currency, market expansion)
 * - Spices (Indian spice trade: trade bonus & feasts)
 * - Knowledge (learning from the Learn & Earn arena)
 */

class ResourceManager {
  static CORE_RESOURCES = ['food', 'water', 'materials', 'wealth', 'spices', 'knowledge'];

  /**
   * Create initial resource store for a player
   */
  static createInitialResources(starting = { food: 5, water: 5, materials: 5, wealth: 5 }) {
    return {
      food: Math.max(0, starting.food ?? 5),
      water: Math.max(0, starting.water ?? 5),
      materials: Math.max(0, starting.materials ?? 5),
      wealth: Math.max(0, starting.wealth ?? 5),
      spices: Math.max(0, starting.spices ?? 2),
      knowledge: Math.max(0, starting.knowledge ?? 0)
    };
  }

  /**
   * Check if player has sufficient resources for a cost object
   */
  static hasEnough(current, cost) {
    if (!current || !cost) return false;
    for (const res of this.CORE_RESOURCES) {
      const required = cost[res] || 0;
      const available = current[res] || 0;
      if (available < required) {
        return false;
      }
    }
    return true;
  }

  /**
   * Deduct costs from current resources without going below 0.
   * Returns { success: boolean, deducted: object, remaining: object, missing: object }
   */
  static deduct(current, cost) {
    if (!this.hasEnough(current, cost)) {
      const missing = {};
      for (const res of this.CORE_RESOURCES) {
        const diff = (cost[res] || 0) - (current[res] || 0);
        if (diff > 0) missing[res] = diff;
      }
      return { success: false, missing, current: { ...current } };
    }

    for (const res of this.CORE_RESOURCES) {
      const required = cost[res] || 0;
      current[res] = Math.max(0, (current[res] || 0) - required);
    }

    return { success: true, remaining: { ...current } };
  }

  /**
   * Add resource deltas to current resources
   */
  static add(current, delta) {
    if (!current || !delta) return current;
    for (const res of this.CORE_RESOURCES) {
      if (typeof delta[res] === 'number') {
        current[res] = Math.max(0, (current[res] || 0) + delta[res]);
      }
    }
    return current;
  }

  /**
   * Collect turn production based on civilization buildings
   * Base: +1 Food, +1 Water, +1 Materials, +1 Wealth
   * Plus active building yields (e.g. Farm yields +2 extra Food)
   */
  static collectTurnYield(player) {
    const yieldDelta = {
      food: 1,
      water: 1,
      materials: 1,
      wealth: 1,
      spices: 1,
      knowledge: 0
    };

    // Farm yields +2 extra Food per turn
    if (player.buildings && player.buildings.FARM) {
      yieldDelta.food += 2;
    }

    // Market yields +1 extra Wealth on regular collections
    if (player.buildings && player.buildings.MARKET) {
      yieldDelta.wealth += 1;
    }

    this.add(player.resources, yieldDelta);

    player.stats.totalResourcesCollected = (player.stats.totalResourcesCollected || 0) + 
      (yieldDelta.food + yieldDelta.water + yieldDelta.materials + yieldDelta.wealth);

    return yieldDelta;
  }
}

module.exports = ResourceManager;
