/**
 * CHAKRA-BHARAT: Server
 * Express HTTP + WebSocket Server & Static File Host
 */

const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
const cors = require('cors');
const { WebSocketServer } = require('ws');

const GameEngine = require('./game/gameEngine');
const HardwareManager = require('./hardware/serial');

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

const PORT = process.env.PORT || 3000;

// Initialize Core Systems
const gameEngine = new GameEngine();
const hardwareManager = new HardwareManager(gameEngine);

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

// WebSocket broadcast helper
function broadcast(type, payload) {
  const message = JSON.stringify({ type, payload, timestamp: new Date().toISOString() });
  wss.clients.forEach(client => {
    if (client.readyState === 1) { // OPEN
      client.send(message);
    }
  });
}

// Hook GameEngine state updates to WebSocket
gameEngine.onStateChange((eventType, state, meta) => {
  broadcast('STATE_UPDATE', { eventType, state, meta });
});

// Hook Hardware telemetry updates to WebSocket
hardwareManager.on('telemetry', telemetry => {
  broadcast('HARDWARE_TELEMETRY', telemetry);
});

hardwareManager.on('status', status => {
  broadcast('HARDWARE_STATUS', status);
});

// WebSocket Client Handlers
wss.on('connection', ws => {
  console.log('[WebSocket] Client connected');

  // Send initial state & hardware status
  ws.send(JSON.stringify({
    type: 'INIT_STATE',
    payload: {
      state: gameEngine.getState(),
      hardware: hardwareManager.getStatus()
    }
  }));

  ws.on('message', data => {
    try {
      const msg = JSON.parse(data.toString());
      switch (msg.type) {
        case 'ACTION': {
          const result = gameEngine.executeAction(msg.playerId, msg.actionType, msg.payload);
          ws.send(JSON.stringify({ type: 'ACTION_RESULT', payload: result }));
          break;
        }
        case 'HARDWARE_COMMAND': {
          const result = hardwareManager.simulateInput(msg.command);
          ws.send(JSON.stringify({ type: 'HARDWARE_RESULT', payload: result }));
          break;
        }
        case 'DEMO_STEP': {
          const result = gameEngine.runDemoStep(msg.step);
          ws.send(JSON.stringify({ type: 'DEMO_RESULT', payload: result }));
          break;
        }
        case 'DISMISS_EVENT': {
          const result = gameEngine.dismissCurrentEvent();
          ws.send(JSON.stringify({ type: 'EVENT_DISMISSED', payload: result }));
          break;
        }
        case 'GET_STATE': {
          ws.send(JSON.stringify({ type: 'STATE_UPDATE', payload: { state: gameEngine.getState() } }));
          break;
        }
        default:
          console.warn('[WebSocket] Unknown message type:', msg.type);
      }
    } catch (err) {
      console.error('[WebSocket] Message parse error:', err.message);
    }
  });

  ws.on('close', () => {
    console.log('[WebSocket] Client disconnected');
  });
});

// ================= REST API ROUTES =================

// Game State
app.get('/api/game/state', (req, res) => {
  res.json({ success: true, state: gameEngine.getState() });
});

// Create / Setup Game
app.post('/api/game/create', (req, res) => {
  const { mode, players } = req.body;
  const state = gameEngine.createGame({ mode, players });
  res.json({ success: true, state });
});

// Execute Action
app.post('/api/game/action', (req, res) => {
  const { playerId, actionType, payload } = req.body;
  const result = gameEngine.executeAction(playerId, actionType, payload);
  res.json({ success: result.success, result, state: gameEngine.getState() });
});

// Dismiss Event
app.post('/api/game/event/dismiss', (req, res) => {
  const result = gameEngine.dismissCurrentEvent();
  res.json({ success: true, result, state: gameEngine.getState() });
});

// Trigger Manual Event
app.post('/api/game/event/trigger', (req, res) => {
  const { eventId } = req.body;
  const event = eventId ? gameEngine.eventManager.getEvent(eventId) : gameEngine.eventManager.drawRandomEvent();
  if (!event) return res.status(404).json({ success: false, reason: 'Event not found' });
  const result = gameEngine.resolveEvent(event);
  res.json({ success: true, result, state: gameEngine.getState() });
});

// Reset Game
app.post('/api/game/reset', (req, res) => {
  gameEngine.reset();
  gameEngine.notifyStateChange('GAME_RESET');
  res.json({ success: true, state: gameEngine.getState() });
});

// Quick Demo Step
app.post('/api/demo/step', (req, res) => {
  const { step } = req.body;
  const result = gameEngine.runDemoStep(parseInt(step, 10));
  res.json({ success: result.success, result, state: gameEngine.getState() });
});

// Hardware Telemetry & Status
app.get('/api/hardware/status', (req, res) => {
  res.json({ success: true, status: hardwareManager.getStatus() });
});

// Hardware Command (Virtual or Injected)
app.post('/api/hardware/command', (req, res) => {
  const { command } = req.body;
  const result = hardwareManager.simulateInput(command);
  res.json({ success: true, result, telemetry: hardwareManager.telemetry, state: gameEngine.getState() });
});

// Explainable AI / LIME report for the completed game
app.get('/api/game/explainability', (req, res) => {
  res.json({
    success: true,
    ready: gameEngine.status === 'GAME_OVER',
    explanations: gameEngine.explainability || []
  });
});

// Catalogs
app.get('/api/data/buildings', (req, res) => {
  res.json({ success: true, buildings: gameEngine.buildingManager.getAllBuildings() });
});

app.get('/api/data/events', (req, res) => {
  res.json({ success: true, events: gameEngine.eventManager.getAllEvents() });
});

app.get('/api/data/modes', (req, res) => {
  res.json({ success: true, modes: gameEngine.gameModes });
});

const os = require('os');
const ResourceManager = require('./game/resources');

function runProc(cmd, args, input, cwd, ms = 8000) {
  return new Promise(resolve => {
    let out = '', err = '', done = false;
    const p = spawn(cmd, args, { cwd });
    const t = setTimeout(() => { if (!done) { p.kill('SIGKILL'); err += '\nTime limit exceeded (8s)'; } }, ms);
    p.stdout.on('data', d => { out += d; if (out.length > 20000) p.kill('SIGKILL'); });
    p.stderr.on('data', d => { err += d; });
    p.on('error', e => { done = true; clearTimeout(t); resolve({ code: -1, out, err: `Cannot start "${cmd}": ${e.message}. Install it to enable this language.` }); });
    p.on('close', code => { done = true; clearTimeout(t); resolve({ code, out, err }); });
    p.stdin.on('error', () => {});
    p.stdin.end(input || '');
  });
}

const builtin = require('./game/cinterp');
const NEED = (what, where) => `${what} is not installed on this computer, so this language cannot run here.\nInstall it from ${where}, or pick C, C++ or JavaScript - those always work.`;

app.post('/api/run', async (req, res) => {
  const { lang, code, stdin } = req.body || {};
  if (typeof code !== 'string' || code.length > 20000) return res.json({ ok: false, stderr: 'Invalid or too large source' });
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'cb-'));
  try {
    let r;
    if (lang === 'c') {
      fs.writeFileSync(path.join(dir, 'main.c'), code);
      const cc = process.env.FORCE_BUILTIN === '1' ? { code: -1 } : await runProc('gcc', ['main.c', '-O1', '-o', 'main', '-lm'], '', dir, 15000);
      if (cc.code === -1) return res.json({ ...builtin.run(code, stdin), engine: 'built-in' });
      if (cc.code !== 0) return res.json({ ok: false, stderr: 'Compilation error:\n' + cc.err });
      r = await runProc(path.join(dir, 'main'), [], stdin, dir);
    } else if (lang === 'cpp') {
      fs.writeFileSync(path.join(dir, 'main.cpp'), code);
      const cc = process.env.FORCE_BUILTIN === '1' ? { code: -1 } : await runProc('g++', ['main.cpp', '-O1', '-std=c++17', '-o', 'main'], '', dir, 20000);
      if (cc.code === -1) return res.json({ ...builtin.run(code, stdin), engine: 'built-in' });
      if (cc.code !== 0) return res.json({ ok: false, stderr: 'Compilation error:\n' + cc.err });
      r = await runProc(path.join(dir, 'main'), [], stdin, dir);
    } else if (lang === 'go') {
      fs.writeFileSync(path.join(dir, 'main.go'), code);
      r = await runProc('go', ['run', 'main.go'], stdin, dir, 20000);
    } else if (lang === 'php') {
      fs.writeFileSync(path.join(dir, 'main.php'), code);
      r = await runProc('php', ['main.php'], stdin, dir);
    } else if (lang === 'ruby') {
      fs.writeFileSync(path.join(dir, 'main.rb'), code);
      r = await runProc('ruby', ['main.rb'], stdin, dir);
    } else if (lang === 'java') {
      fs.writeFileSync(path.join(dir, 'Main.java'), code);
      const jc = await runProc('javac', ['Main.java'], '', dir, 20000);
      if (jc.code === -1) return res.json({ ok: false, stderr: NEED('Java JDK', 'https://adoptium.net') });
      if (jc.code !== 0) return res.json({ ok: false, stderr: 'Compilation error:\n' + jc.err });
      r = await runProc('java', ['-cp', dir, 'Main'], stdin, dir, 10000);
    } else if (lang === 'python') {
      fs.writeFileSync(path.join(dir, 'main.py'), code);
      for (const exe of ['python3', 'python', 'py']) { r = await runProc(exe, ['main.py'], stdin, dir); if (r.code !== -1) break; }
      if (r.code === -1) return res.json({ ok: false, stderr: NEED('Python', 'https://python.org (tick "Add Python to PATH")') });
    } else if (lang === 'javascript') {
      fs.writeFileSync(path.join(dir, 'main.js'), code);
      r = await runProc(process.execPath, ['main.js'], stdin, dir);
    } else return res.json({ ok: false, stderr: 'Unsupported language' });
    if (r.code === -1) return res.json({ ok: false, stderr: NEED(lang, 'its official website') });
    res.json({ ok: r.code === 0, stdout: r.out, stderr: r.err });
  } catch (e) {
    res.json({ ok: false, stderr: e.message });
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

// Which compilers are installed on this machine?
app.get('/api/languages', async (req, res) => {
  const probes = { c: ['gcc', '--version'], cpp: ['g++', '--version'], java: ['javac', '-version'], python: [process.platform === 'win32' ? 'python' : 'python3', '--version'], javascript: [process.execPath, '--version'], go: ['go', 'version'], php: ['php', '--version'], ruby: ['ruby', '--version'] };
  const out = {};
  for (const [k, [c, ...a]] of Object.entries(probes)) out[k] = (await runProc(c, a, '', os.tmpdir(), 4000)).code !== -1;
  out.c = out.cpp = true; // built-in engine covers C and C++
  res.json({ success: true, languages: out });
});

// Tokens earned by solving coding tasks become kingdom resources
app.post('/api/tokens/award', (req, res) => {
  const player = gameEngine.getPlayer(req.body.playerId);
  const tokens = Math.max(0, Math.min(30, parseInt(req.body.tokens, 10) || 0));
  if (!player) return res.json({ success: false, reason: 'No such player. Start a game first.' });
  const b = req.body || {};
  // Score-based payout: tokens spread over all 6 resources, knowledge always earned from learning
  const q = Math.floor(tokens / 3), h = Math.floor(tokens / 2);
  const delta = { materials: h, food: q, water: q, wealth: q + (b.bonus ? 1 : 0), spices: Math.floor(tokens / 4), knowledge: Math.max(tokens ? 1 : 0, Math.floor(tokens / 2)) };
  ResourceManager.add(player.resources, delta);
  gameEngine.logAction(player.id, 'TOKENS_AWARDED', { tokens });
  gameEngine.notifyStateChange('TOKENS_AWARDED', { playerId: player.id, tokens });
  res.json({ success: true, delta, resources: player.resources, state: gameEngine.getState() });
});

// Server Initialization
server.listen(PORT, async () => {
  console.log(`=======================================================`);
  console.log(`  CHAKRA-BHARAT: Smart Indian Civilization Strategy Game`);
  console.log(`  Server running at: http://localhost:${PORT}`);
  console.log(`=======================================================`);

  // Initialize hardware bridge (attempts serial port, falls back to Virtual)
  await hardwareManager.initSerial();
});

module.exports = { app, server, gameEngine, hardwareManager };
