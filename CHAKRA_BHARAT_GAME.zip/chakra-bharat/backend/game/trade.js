/**
 * CHAKRA-BHARAT: Trade Manager
 * Supports:
 * 1. Player-to-Player diplomacy & resource negotiation
 * 2. Caravan Merchant Exchange (Bank trade: 2-for-1 or 3-for-2 with Market)
 */

const ResourceManager = require('./resources');

class TradeManager {
  constructor() {
    this.pendingTrades = new Map();
    this.tradeCounter = 0;
    this.tradeHistory = [];
  }

  /**
   * Propose a trade from one player to another
   * offer: { food, water, materials, wealth }
   * request: { food, water, materials, wealth }
   */
  proposeTrade(fromPlayer, toPlayer, offer, request) {
    if (!fromPlayer || !toPlayer) {
      return { success: false, reason: 'Invalid players for trade.' };
    }
    if (fromPlayer.id === toPlayer.id) {
      return { success: false, reason: 'Cannot trade with yourself.' };
    }

    // Validate that fromPlayer has the offered resources
    if (!ResourceManager.hasEnough(fromPlayer.resources, offer)) {
      return { success: false, reason: `${fromPlayer.name} does not have sufficient resources to offer.` };
    }

    const tradeId = `TRD-${++this.tradeCounter}`;
    const tradeProposal = {
      id: tradeId,
      fromPlayerId: fromPlayer.id,
      fromPlayerName: fromPlayer.name,
      toPlayerId: toPlayer.id,
      toPlayerName: toPlayer.name,
      offer: { ...offer },
      request: { ...request },
      status: 'PENDING',
      createdAt: new Date().toISOString()
    };

    this.pendingTrades.set(tradeId, tradeProposal);
    return { success: true, trade: tradeProposal };
  }

  /**
   * Accept an existing trade proposal
   */
  acceptTrade(tradeId, players) {
    const trade = this.pendingTrades.get(tradeId);
    if (!trade) {
      return { success: false, reason: 'Trade proposal not found or already resolved.' };
    }
    if (trade.status !== 'PENDING') {
      return { success: false, reason: `Trade is already ${trade.status}.` };
    }

    const fromPlayer = players.find(p => p.id === trade.fromPlayerId);
    const toPlayer = players.find(p => p.id === trade.toPlayerId);

    if (!fromPlayer || !toPlayer) {
      return { success: false, reason: 'One or more participating players not found.' };
    }

    // Verify both parties still hold required resources
    if (!ResourceManager.hasEnough(fromPlayer.resources, trade.offer)) {
      trade.status = 'CANCELLED_INSUFFICIENT_OFFER';
      this.pendingTrades.delete(tradeId);
      return { success: false, reason: `${fromPlayer.name} no longer has the offered resources.` };
    }
    if (!ResourceManager.hasEnough(toPlayer.resources, trade.request)) {
      return { success: false, reason: `${toPlayer.name} does not have the requested resources.` };
    }

    // Atomic resource transfer
    ResourceManager.deduct(fromPlayer.resources, trade.offer);
    ResourceManager.add(fromPlayer.resources, trade.request);

    ResourceManager.deduct(toPlayer.resources, trade.request);
    ResourceManager.add(toPlayer.resources, trade.offer);

    // Update player trade stats
    fromPlayer.stats.tradesCompleted = (fromPlayer.stats.tradesCompleted || 0) + 1;
    toPlayer.stats.tradesCompleted = (toPlayer.stats.tradesCompleted || 0) + 1;

    // Market synergy: if either player has a Market, they gain +1 Wealth tariff
    if (fromPlayer.buildings?.MARKET) {
      ResourceManager.add(fromPlayer.resources, { wealth: 1 });
      fromPlayer.stats.timesBenefitedByMarket = (fromPlayer.stats.timesBenefitedByMarket || 0) + 1;
    }
    if (toPlayer.buildings?.MARKET) {
      ResourceManager.add(toPlayer.resources, { wealth: 1 });
      toPlayer.stats.timesBenefitedByMarket = (toPlayer.stats.timesBenefitedByMarket || 0) + 1;
    }

    trade.status = 'ACCEPTED';
    trade.completedAt = new Date().toISOString();
    this.pendingTrades.delete(tradeId);
    this.tradeHistory.push(trade);

    return {
      success: true,
      trade,
      fromPlayerResources: { ...fromPlayer.resources },
      toPlayerResources: { ...toPlayer.resources }
    };
  }

  /**
   * Reject an existing trade proposal
   */
  rejectTrade(tradeId) {
    const trade = this.pendingTrades.get(tradeId);
    if (!trade) {
      return { success: false, reason: 'Trade proposal not found.' };
    }
    trade.status = 'REJECTED';
    this.pendingTrades.delete(tradeId);
    return { success: true, trade };
  }

  /**
   * Caravan Guild Merchant Exchange (Single-player / Bank exchange)
   * Exchange 2 of giveResource for 1 of getResource.
   * If player has MARKET, exchange rate improves to 3-for-2 or gives +1 bonus.
   */
  tradeWithCaravan(player, giveResource, getResource, amount = 1) {
    if (!giveResource || !getResource) {
      return { success: false, reason: 'Must specify valid resources to exchange.' };
    }
    if (giveResource === getResource) {
      return { success: false, reason: 'Cannot exchange the same resource.' };
    }

    const hasMarket = !!(player.buildings && player.buildings.MARKET);
    // Standard: 2 give for 1 get. With Market: 2 give for 1 get + 1 bonus wealth every 2 trades
    const costRatio = 2;
    const totalCost = { [giveResource]: amount * costRatio };

    if (!ResourceManager.hasEnough(player.resources, totalCost)) {
      return {
        success: false,
        reason: `Need ${amount * costRatio} ${giveResource} to acquire ${amount} ${getResource}.`,
        needed: totalCost
      };
    }

    ResourceManager.deduct(player.resources, totalCost);
    const gains = { [getResource]: amount };

    // Market perk: gives +1 wealth commission on caravan exchange
    if (hasMarket) {
      gains.wealth = (gains.wealth || 0) + 1;
      player.stats.timesBenefitedByMarket = (player.stats.timesBenefitedByMarket || 0) + 1;
    }

    ResourceManager.add(player.resources, gains);
    player.stats.tradesCompleted = (player.stats.tradesCompleted || 0) + 1;

    return {
      success: true,
      deducted: totalCost,
      gained: gains,
      hasMarketPerk: hasMarket,
      remainingResources: { ...player.resources }
    };
  }

  getPendingTradesForPlayer(playerId) {
    return Array.from(this.pendingTrades.values()).filter(
      t => t.toPlayerId === playerId || t.fromPlayerId === playerId
    );
  }
}

module.exports = TradeManager;
