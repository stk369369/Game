/**
 * CHAKRA-BHARAT: Turn Manager
 * Coordinates turn progression, rounds, active player rotation, and phase transitions.
 */

class TurnManager {
  constructor(maxRounds = 8, playerCount = 2) {
    this.maxRounds = maxRounds;
    this.playerCount = playerCount;
    this.currentRound = 1;
    this.currentPlayerIndex = 0;
    this.turnInRound = 1;
    this.phase = 'START'; // 'START', 'ACTION', 'EVENT', 'ROUND_END', 'FINISHED'
    this.actionsTakenThisTurn = 0;
    this.turnHistory = [];
  }

  getCurrentPlayerId(players) {
    if (!players || players.length === 0) return 1;
    return players[this.currentPlayerIndex % players.length].id;
  }

  isRoundComplete() {
    return this.turnInRound >= this.playerCount;
  }

  isGameComplete() {
    return this.currentRound > this.maxRounds;
  }

  recordAction(actionType, details = {}) {
    this.actionsTakenThisTurn++;
    this.turnHistory.push({
      round: this.currentRound,
      playerIndex: this.currentPlayerIndex,
      actionType,
      details,
      timestamp: new Date().toISOString()
    });
  }

  /**
   * End current player's turn.
   * Returns { nextPlayerIndex, roundAdvanced, isEventDue, isGameOver }
   */
  nextTurn() {
    this.actionsTakenThisTurn = 0;
    let roundAdvanced = false;
    let isEventDue = false;

    if (this.isRoundComplete()) {
      // Completed all players in this round
      roundAdvanced = true;
      isEventDue = true;
      this.currentRound++;
      this.turnInRound = 1;
      this.currentPlayerIndex = 0;
    } else {
      this.turnInRound++;
      this.currentPlayerIndex = (this.currentPlayerIndex + 1) % this.playerCount;
    }

    const isGameOver = this.isGameComplete();
    if (isGameOver) {
      this.phase = 'FINISHED';
    } else if (isEventDue) {
      this.phase = 'EVENT';
    } else {
      this.phase = 'ACTION';
    }

    return {
      round: this.currentRound,
      turnInRound: this.turnInRound,
      currentPlayerIndex: this.currentPlayerIndex,
      roundAdvanced,
      isEventDue,
      isGameOver,
      phase: this.phase
    };
  }

  reset(maxRounds, playerCount) {
    this.maxRounds = maxRounds || this.maxRounds;
    this.playerCount = playerCount || this.playerCount;
    this.currentRound = 1;
    this.currentPlayerIndex = 0;
    this.turnInRound = 1;
    this.phase = 'START';
    this.actionsTakenThisTurn = 0;
    this.turnHistory = [];
  }
}

module.exports = TurnManager;
