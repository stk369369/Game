/**
 * CHAKRA-BHARAT: Client Application Orchestrator
 * Full-stack state sync, WebSocket bridge, view transitions, audio triggers,
 * board mirroring, event modal management, and virtual hardware simulation.
 */

// Global Client State
const AppState = {
  currentPage: 'start',
  game: null,
  hardware: null,
  ws: null,
  selectedMode: 'basic',
  playerCount: 2,
  isVirtualTrayOpen: false,
  demoStep: 1,
  activeTradeTab: 'player'
};

// =============================================================================
// INITIALIZATION & WEBSOCKET
// =============================================================================

document.addEventListener('DOMContentLoaded', () => {
  initWebSocket();
  const initialRoute = window.location.hash === '#board' ? 'board' : (window.location.hash === '#start' ? 'start' : 'home');
  navigateTo(initialRoute);

  // Periodically poll hardware status if WS is reconnecting
  setInterval(pollHardwareStatus, 4000);
});

function initWebSocket() {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const wsUrl = `${protocol}//${window.location.host}`;

  try {
    AppState.ws = new WebSocket(wsUrl);

    AppState.ws.onopen = () => {
      console.log('[App] WebSocket connected to Game Engine');
    };

    AppState.ws.onmessage = event => {
      try {
        const msg = JSON.parse(event.data);
        handleServerMessage(msg);
      } catch (err) {
        console.error('[App] Failed to parse WS message:', err);
      }
    };

    AppState.ws.onclose = () => {
      console.warn('[App] WebSocket disconnected. Retrying in 2s...');
      setTimeout(initWebSocket, 2000);
    };

    AppState.ws.onerror = err => {
      console.warn('[App] WebSocket error:', err.message);
    };
  } catch (err) {
    console.warn('[App] WebSocket init failed:', err.message);
  }
}

function sendWs(type, payload = {}) {
  if (AppState.ws && AppState.ws.readyState === WebSocket.OPEN) {
    AppState.ws.send(JSON.stringify({ type, ...payload }));
  } else {
    // Fallback to HTTP REST
    fallbackRestAction(type, payload);
  }
}

async function fallbackRestAction(type, payload) {
  if (type === 'ACTION') {
    await fetch('/api/game/action', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
  } else if (type === 'HARDWARE_COMMAND') {
    await fetch('/api/hardware/command', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
  } else if (type === 'DISMISS_EVENT') {
    await fetch('/api/game/event/dismiss', { method: 'POST' });
  }
}

function handleServerMessage(msg) {
  switch (msg.type) {
    case 'INIT_STATE':
      AppState.game = msg.payload.state;
      AppState.hardware = msg.payload.hardware;
      updateHardwareStatusUI(msg.payload.hardware);
      renderActivePage();
      break;

    case 'STATE_UPDATE':
      const prevState = AppState.game;
      AppState.game = msg.payload.state;
      handleStateTransitions(prevState, AppState.game, msg.payload.eventType, msg.payload.meta);
      renderActivePage();
      break;

    case 'HARDWARE_TELEMETRY':
      AppState.hardware = AppState.hardware || {};
      AppState.hardware.telemetry = msg.payload;
      updateSmartBoardTelemetry(msg.payload);
      break;

    case 'HARDWARE_STATUS':
      AppState.hardware = msg.payload;
      updateHardwareStatusUI(msg.payload);
      break;

    case 'EVENT_TRIGGERED':
      if (msg.payload && msg.payload.event) {
        showEventModal(msg.payload.event, msg.payload.consequences);
      }
      break;
  }
}

function handleStateTransitions(prev, curr, eventType, meta) {
  if (!curr) return;

  // Sound & Toast Feedback based on events
  if (eventType === 'BUILD_SUCCESS') {
    window.soundEngine?.playBuild();
    showToast(`✓ Constructed ${meta?.building?.name || 'Building'}!`);
  } else if (eventType === 'COLLECT_SUCCESS') {
    window.soundEngine?.playCoins();
    showToast(`🌾 Collected seasonal harvest yields!`);
  } else if (eventType === 'TRADE_ACCEPTED') {
    window.soundEngine?.playCoins();
    showToast(`🤝 Trade proposal successfully executed!`);
  } else if (eventType === 'CARAVAN_TRADE_SUCCESS') {
    window.soundEngine?.playCoins();
    showToast(`🐫 Exchanged commodities with Caravan Guild!`);
  } else if (eventType === 'SPECIAL_ACTION_SUCCESS') {
    window.soundEngine?.playFestival();
    showToast(`🍛 Annadanam food feast shared (-1 Food, +1 Water, +2 Culture)`);
  } else if (eventType === 'ACTION_REJECTED') {
    window.soundEngine?.playClick();
    showToast(`⚠ ${meta?.actionType || 'Action'} rejected: ${meta?.reason || 'Check the rules.'}`);
  }

  // Check Game Over
  if (curr.status === 'GAME_OVER' && AppState.currentPage !== 'result') {
    window.soundEngine?.playVictory();
    navigateTo('result');
    return;
  }

  // Check for active Event modal
  if (curr.status === 'EVENT' && curr.currentEvent) {
    showEventModal(curr.currentEvent, curr.lastConsequences);
  } else if (curr.status !== 'EVENT' && !curr.currentEvent) {
    hideEventModal();
  }
}

// =============================================================================
// NAVIGATION & PAGE ROUTING
// =============================================================================

async function navigateTo(pageName) {
  AppState.currentPage = pageName;
  window.soundEngine?.playClick();

  const mount = document.getElementById('page-mount');
  if (!mount) return;

  try {
    const response = await fetch(`pages/${pageName}.html`);
    if (!response.ok) throw new Error(`Could not load page: ${pageName}`);
    const html = await response.text();
    mount.innerHTML = html;

    renderActivePage();
  } catch (err) {
    console.error(`[App] Navigation error for ${pageName}:`, err);
  }
}

function renderActivePage() {
  switch (AppState.currentPage) {
    case 'start':
      bindStartPage();
      break;
    case 'game':
      bindGamePage();
      break;
    case 'result':
      bindResultPage();
      break;
    case 'board':
      bindBoardPage();
      break;
  }
}

// =============================================================================
// 1. START PAGE LOGIC
// =============================================================================

function bindStartPage() {
  selectGameMode(AppState.selectedMode || 'basic');
  renderPlayerSetupCards();
}

function selectGameMode(mode) {
  AppState.selectedMode = mode;
  document.querySelectorAll('.mode-option-card').forEach(el => {
    el.classList.remove('selected');
  });
  const target = document.getElementById(`mode-${mode}`);
  if (target) target.classList.add('selected');
}

function renderPlayerSetupCards() {
  const container = document.getElementById('setup-players-container');
  if (!container) return;

  const defaultPlayers = [
    { id: 1, name: 'Arjun', civ: 'Indus Builders', emblem: '☸', color: '#D4AF37', subtitle: 'Tabletop Commander' },
    { id: 2, name: 'Vikram', civ: 'Vedic Pioneers', emblem: '🪷', color: '#3182CE', subtitle: 'Civilization Strategist' },
    { id: 3, name: 'Ananya', civ: 'Maurya Artisans', emblem: '🌳', color: '#38A169', subtitle: 'Regional Governor' },
    { id: 4, name: 'Rohan', civ: 'Chola Navigators', emblem: '☀️', color: '#DD6B20', subtitle: 'Maritime Guild' }
  ];

  let html = '';
  for (let i = 0; i < AppState.playerCount; i++) {
    const p = defaultPlayers[i];
    html += `
      <div class="player-setup-card active" id="player-setup-${p.id}">
        <div class="player-card-badge">
          <div class="player-badge-icon" style="background: rgba(255,255,255,0.08); color: ${p.color}; border: 1px solid ${p.color};">
            ${p.emblem}
          </div>
          <div>
            <h4 style="font-size: 1rem; color: ${p.color};">Player ${p.id}</h4>
            <span style="font-size: 0.72rem; color: var(--text-muted);">${p.subtitle}</span>
          </div>
        </div>
        <label style="font-size: 0.75rem; color: var(--text-muted);">Player Name</label>
        <input type="text" class="input-field" id="p${p.id}-name" value="${p.name}" />
        <label style="font-size: 0.75rem; color: var(--text-muted);">Civilization Realm</label>
        <input type="text" class="input-field" id="p${p.id}-civ" value="${p.civ}" />
      </div>
    `;
  }
  container.innerHTML = html;
}

function addPlayerConfig() {
  if (AppState.playerCount < 4) {
    AppState.playerCount++;
    renderPlayerSetupCards();
    window.soundEngine?.playClick();
  }
}

function removePlayerConfig() {
  if (AppState.playerCount > 2) {
    AppState.playerCount--;
    renderPlayerSetupCards();
    window.soundEngine?.playClick();
  }
}

async function handleStartGame() {
  sessionStorage.removeItem('cbLearnLog'); sessionStorage.removeItem('cbLearnRound');
  window.soundEngine?.playClick();

  const players = [];
  for (let i = 1; i <= AppState.playerCount; i++) {
    const nameInput = document.getElementById(`p${i}-name`);
    const civInput = document.getElementById(`p${i}-civ`);
    players.push({
      id: i,
      name: nameInput ? nameInput.value.trim() || `Player ${i}` : `Player ${i}`,
      civilizationName: civInput ? civInput.value.trim() || `Civilization ${i}` : `Civilization ${i}`
    });
  }

  try {
    const res = await fetch('/api/game/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mode: AppState.selectedMode, players })
    });
    const data = await res.json();
    if (data.success) {
      AppState.game = data.state;
      navigateTo('game');
    }
  } catch (err) {
    console.error('Failed to create game:', err);
  }
}

// =============================================================================
// 2. GAME DASHBOARD BINDINGS & MIRROR
// =============================================================================

function bindGamePage() {
  if (!AppState.game) {
    fetchGameState();
    return;
  }

  const game = AppState.game;
  const activePlayer = game.players.find(p => p.id === game.activePlayerId) || game.players[0];

  // 1. Update Active Player Header & Banner
  const nameEl = document.getElementById('player-active-name');
  const userEl = document.getElementById('player-active-user');
  const emblemEl = document.getElementById('player-active-emblem');
  const bannerCiv = document.getElementById('banner-civ-title');
  const bannerPlayer = document.getElementById('banner-player-name');
  const bannerEmblem = document.getElementById('banner-emblem');
  const roundInd = document.getElementById('round-indicator');
  const liveScore = document.getElementById('player-live-score');

  if (nameEl && activePlayer) {
    nameEl.textContent = activePlayer.civilizationName;
    nameEl.style.color = activePlayer.badge?.color || '#D4AF37';
  }
  if (userEl && activePlayer) userEl.textContent = `Leader: ${activePlayer.name}`;
  if (emblemEl && activePlayer) {
    emblemEl.textContent = activePlayer.badge?.symbol || '☸';
    emblemEl.style.borderColor = activePlayer.badge?.color || '#D4AF37';
  }
  if (bannerCiv && activePlayer) bannerCiv.textContent = activePlayer.civilizationName.toUpperCase();
  if (bannerPlayer && activePlayer) bannerPlayer.textContent = `${activePlayer.name}'s Turn`;
  if (bannerEmblem && activePlayer) bannerEmblem.textContent = activePlayer.badge?.symbol || '☸';
  if (roundInd) {
    const r = String(game.currentRound).padStart(2, '0');
    const m = String(game.maxRounds).padStart(2, '0');
    roundInd.textContent = `ROUND ${r} / ${m}`;
  }
  if (liveScore && activePlayer) {
    liveScore.textContent = `${activePlayer.score || 0} / 100`;
  }

  // 2. Update Resource Counters with smooth transition
  if (activePlayer && activePlayer.resources) {
    animateValue('val-food', activePlayer.resources.food);
    animateValue('val-water', activePlayer.resources.water);
    animateValue('val-materials', activePlayer.resources.materials);
    animateValue('val-wealth', activePlayer.resources.wealth);
    animateValue('val-spices', activePlayer.resources.spices || 0);
    animateValue('val-knowledge', activePlayer.resources.knowledge || 0);

    // Delta tags
    const foodDelta = document.getElementById('delta-food');
    if (foodDelta) {
      foodDelta.textContent = activePlayer.buildings?.FARM ? '+3 / turn (Farm)' : '+1 / turn';
    }
  }

  // 3. Update Mini Players List
  const miniList = document.getElementById('players-mini-list');
  if (miniList && game.players) {
    miniList.innerHTML = game.players.map(p => {
      const isActive = p.id === game.activePlayerId;
      return `
        <div style="display: flex; justify-content: space-between; align-items: center; padding: 6px 8px; border-radius: 6px; background: ${isActive ? 'rgba(212,175,55,0.15)' : 'transparent'}; border-left: 3px solid ${p.badge?.color || '#FFF'}; margin-bottom: 4px;">
          <div style="display: flex; align-items: center; gap: 6px;">
            <span>${p.badge?.symbol || '☸'}</span>
            <span style="font-size: 0.8rem; font-weight: ${isActive ? '700' : '400'}; color: ${isActive ? 'var(--gold-light)' : 'var(--text-secondary)'};">
              ${p.civilizationName}
            </span>
          </div>
          <span style="font-family: var(--font-mono); font-size: 0.85rem; color: var(--gold-light);">
            ${p.score || 0} pts
          </span>
        </div>
      `;
    }).join('');
  }

  // 4. Update Physical Board Mirror (4 Plots)
  if (activePlayer && activePlayer.buildings) {
    updateBoardPlot('FARM', activePlayer.buildings.FARM, '🪨 2, 💧 1');
    updateBoardPlot('WATER_SYSTEM', activePlayer.buildings.WATER_SYSTEM, '🪨 2, 🪙 1');
    updateBoardPlot('MARKET', activePlayer.buildings.MARKET, '🪨 2, 🪙 2');
    updateBoardPlot('FORT', activePlayer.buildings.FORT, '🪨 3, 🌾 1');
  }

  // 5. Render merged 4-partition board
  renderMergedBoard('merged-board');

  // 6. Update Chronicler / Live Log
  renderActionLog(game.actionHistory);

  // 7. Learn & Earn: summary + automatic learning phase before each round
  renderLearnSummary(game);
  if (window.LearnArena && AppState.currentPage === 'game') LearnArena.maybeStart(game);
}

function renderLearnSummary(game) {
  const el = document.getElementById('learn-summary');
  if (!el || !game?.players) return;
  const L = JSON.parse(sessionStorage.cbLearnLog || '[]');
  el.innerHTML = game.players.map(p => {
    const mine = L.filter(r => r.pid === p.id);
    const tok = mine.reduce((a, r) => a + r.tok, 0), ok = mine.reduce((a, r) => a + r.ok, 0), n = mine.reduce((a, r) => a + r.n, 0);
    return `<div class="learn-row" style="border-left:3px solid ${p.badge?.color || '#D4AF37'}"><span>${escapeHtml(p.name)}</span><span>🎓 ${tok} tokens · ${ok}/${n}</span></div>`;
  }).join('');
}
window.refreshAfterLearn = function () { if (AppState.currentPage === 'game') bindGamePage(); };

function bindBoardPage() {
  if (!AppState.game) {
    fetchGameState().then(() => renderFullBoard());
    return;
  }
  renderFullBoard();
}

function renderFullBoard() {
  renderMergedBoard('full-board');
}

function renderMergedBoard(targetId) {
  const host = document.getElementById(targetId);
  const game = AppState.game;
  if (!host || !game?.players) return;
  if (game.players.length === 0) {
    host.innerHTML = `
      <div class="lime-empty large" style="grid-column:1/-1">
        <div style="font-size:2rem;margin-bottom:8px">☸</div>
        <b style="color:var(--gold-light)">No active civilization yet.</b>
        <p style="margin:6px 0 14px">Start a game first, then this board will mirror every player's infrastructure.</p>
        <button class="btn btn-primary" onclick="navigateTo('start')">START GAME</button>
      </div>`;
    return;
  }

  if (window.renderRealBoard) {
    renderRealBoard(host, game);
    const st = document.getElementById('board-status-text');
    const act = game.players.find(p => p.id === game.activePlayerId);
    if (st) st.textContent = act ? `${act.civilizationName} is active · tap a glowing ＋ hex in its territory to build.` : 'Board ready.';
    return;
  }

  host.innerHTML = game.players.map((p, index) => {
    const active = p.id === game.activePlayerId && game.status === 'ACTIVE';
    const color = p.badge?.color || '#D4AF37';
    const placements = p.board?.placements || [];

    let cells = '';
    for (let row = 0; row < 2; row++) {
      for (let col = 0; col < 3; col++) {
        const item = placements.find(x => x.row === row && x.col === col);
        const catalog = (game.buildingsCatalog || []).find(b => b.id === item?.buildingId);
        if (item) {
          cells += `
            <button class="strategy-cell occupied" title="${catalog?.concept || item.name}">
              <div class="strategy-building-icon">${buildingEmoji(item.buildingId)}</div>
              <div class="strategy-building-name">${item.name}</div>
              <div class="strategy-building-round">R${item.round || 1}</div>
            </button>`;
        } else {
          cells += `
            <button class="strategy-cell empty ${active ? 'cursor-ready' : ''}"
              ${active ? `onclick="openBuildModal()"` : 'disabled'}
              title="${active ? 'Build infrastructure here — the engine assigns the next open cell.' : 'Inactive player partition'}">
              <span>${active ? '＋' : '·'}</span>
              <small>${active ? 'BUILD' : 'LOCKED'}</small>
            </button>`;
        }
      }
    }

    return `
      <section class="strategy-quadrant ${active ? 'active' : ''}" style="--quad-color:${color}">
        <header>
          <div class="strategy-player">
            <span class="strategy-emblem">${p.badge?.symbol || '☸'}</span>
            <div><strong>PART ${index + 1} · ${escapeHtml(p.civilizationName)}</strong><small>${escapeHtml(p.name)}</small></div>
          </div>
          <span class="strategy-state">${active ? '● ACTIVE' : '○ WAITING'}</span>
        </header>
        <div class="strategy-grid">${cells}</div>
        <footer>
          <span>${placements.length}/4 infrastructure</span>
          <span>${p.score || 0} pts</span>
        </footer>
      </section>`;
  }).join('');

  const status = document.getElementById('board-status-text');
  if (status) {
    const active = game.players.find(p => p.id === game.activePlayerId);
    status.textContent = active
      ? `${active.civilizationName} is active • Build actions appear in its illuminated quadrant.`
      : 'Board ready.';
  }
}

function buildingEmoji(id) {
  return ({ FARM: '🌾', WATER_SYSTEM: '💧', MARKET: '🪙', FORT: '🛡️' })[id] || '🏛️';
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

function updateBoardPlot(buildingId, isBuilt, costStr) {
  const plotCard = document.getElementById(`plot-${buildingId}`);
  const statusEl = document.getElementById(`plot-status-${buildingId}`);
  if (!plotCard || !statusEl) return;

  if (isBuilt) {
    plotCard.classList.add('built');
    let perkText = '';
    if (buildingId === 'FARM') perkText = '+2 Food Production Active';
    if (buildingId === 'WATER_SYSTEM') perkText = 'Drought Loss Reduced (3 → 1)';
    if (buildingId === 'MARKET') perkText = 'Trade Boom Doubled (+4 Wealth)';
    if (buildingId === 'FORT') perkText = 'Citadel Logistics Stockpile';

    statusEl.innerHTML = `
      <div class="plot-badge-active">✓ BUILT & ACTIVE</div>
      <div style="font-size: 0.75rem; color: #68D391; margin-top: 6px;">${perkText}</div>
    `;
  } else {
    plotCard.classList.remove('built');
    statusEl.innerHTML = `
      <div class="plot-cost-row">Cost: ${costStr}</div>
      <button type="button" class="btn btn-secondary" style="margin-top: 10px; padding: 6px 16px; font-size: 0.8rem;" onclick="triggerBuild('${buildingId}')">
        🔨 BUILD / SCAN
      </button>
    `;
  }
}

function renderActionLog(history = []) {
  const container = document.getElementById('log-stream-container');
  if (!container) return;

  if (history.length === 0) {
    container.innerHTML = '<div style="font-size: 0.78rem; color: var(--text-muted); text-align: center; padding: 20px;">Civilization history will be recorded here...</div>';
    return;
  }

  container.innerHTML = history.slice(0, 15).map(item => {
    let detailText = '';
    if (item.details?.building) detailText = `built <strong>${item.details.building}</strong>`;
    else if (item.details?.event) detailText = `struck by <strong>${item.details.event}</strong>`;
    else if (item.details?.action) detailText = `${item.details.action}`;
    else if (item.details?.yield) detailText = `collected seasonal production`;
    else if (item.details?.gave) detailText = `completed Caravan barter`;
    else detailText = item.actionType.replace('_', ' ');

    const time = item.timestamp ? new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '';

    return `
      <div class="log-item">
        <div style="display: flex; justify-content: space-between;">
          <strong style="color: var(--gold-light);">${item.playerName}</strong>
          <span class="log-timestamp">${time}</span>
        </div>
        <div style="margin-top: 2px;">${detailText}</div>
      </div>
    `;
  }).join('');
}

function animateValue(elementId, targetVal) {
  const el = document.getElementById(elementId);
  if (!el) return;
  const current = parseInt(el.textContent, 10) || 0;
  if (current === targetVal) return;

  el.textContent = targetVal;
  el.style.transform = 'scale(1.2)';
  el.style.color = '#F6E05E';
  setTimeout(() => {
    el.style.transform = 'scale(1)';
    el.style.color = 'var(--text-primary)';
  }, 250);
}

// =============================================================================
// 3. ACTION DISPATCHERS
// =============================================================================

function triggerBuild(buildingId) {
  if (!AppState.game) return;
  window.soundEngine?.playClick();
  sendWs('ACTION', {
    playerId: AppState.game.activePlayerId,
    actionType: 'BUILD',
    payload: { buildingId }
  });
}

function triggerCollect() {
  if (!AppState.game) return;
  window.soundEngine?.playClick();
  sendWs('ACTION', {
    playerId: AppState.game.activePlayerId,
    actionType: 'COLLECT'
  });
}

function triggerSpecialAction() {
  if (!AppState.game) return;
  window.soundEngine?.playClick();
  sendWs('ACTION', {
    playerId: AppState.game.activePlayerId,
    actionType: 'SPECIAL_ACTION'
  });
}

function triggerEndTurn() {
  if (!AppState.game) return;
  window.soundEngine?.playClick();
  sendWs('ACTION', {
    playerId: AppState.game.activePlayerId,
    actionType: 'END_TURN'
  });
}

// =============================================================================
// 4. EVENT OVERLAY & HERO EXPLANATION
// =============================================================================

function showEventModal(event, consequences = []) {
  const modal = document.getElementById('event-modal');
  const card = document.getElementById('event-card-inner');
  const title = document.getElementById('modal-event-title');
  const hindi = document.getElementById('modal-event-hindi');
  const desc = document.getElementById('modal-event-desc');
  const badge = document.getElementById('modal-event-badge');
  const box = document.getElementById('modal-consequence-box');
  const heroCallout = document.getElementById('modal-hero-callout');
  const heroTitle = document.getElementById('modal-hero-title');
  const heroBody = document.getElementById('modal-hero-body');

  if (!modal) return;

  // Sound and visual animation
  if (event.category === 'disaster') {
    window.soundEngine?.playDrought();
    if (card) {
      card.classList.remove('shake');
      void card.offsetWidth; // trigger reflow
      card.classList.add('shake');
    }
  } else if (event.category === 'positive') {
    window.soundEngine?.playMonsoon();
  } else if (event.category === 'cultural') {
    window.soundEngine?.playFestival();
  } else if (event.category === 'economic') {
    window.soundEngine?.playCoins();
  }

  if (title) title.textContent = event.title;
  if (hindi) hindi.textContent = event.hindiTitle || '';
  if (desc) desc.textContent = event.description;
  if (badge) {
    badge.textContent = `${event.category.toUpperCase()} EVENT`;
    badge.className = `event-badge-tag event-badge-${event.category}`;
  }

  // Render Consequence Rows for each player
  if (box && consequences && consequences.length > 0) {
    box.innerHTML = consequences.map(c => {
      const isProtected = c.hasInfrastructure;
      const statusClass = isProtected ? 'protected' : (event.category === 'disaster' ? 'unprotected' : '');
      const badgeIcon = isProtected ? '🛡️ PROTECTED' : (event.category === 'disaster' ? '⚠ UNPROTECTED' : '★ STANDARD');
      return `
        <div class="consequence-player-row ${statusClass}">
          <div>
            <strong style="color: var(--text-primary); font-size: 0.92rem;">${c.civilizationName} (${c.playerName})</strong>
            <div style="font-size: 0.8rem; color: var(--text-secondary); margin-top: 2px;">
              ${c.narrative}
            </div>
          </div>
          <span style="font-size: 0.75rem; font-weight: 700; padding: 4px 8px; border-radius: 4px; background: rgba(0,0,0,0.3); color: ${isProtected ? '#68D391' : '#FC8181'};">
            ${badgeIcon}
          </span>
        </div>
      `;
    }).join('');
  }

  // Hero Explanation for Judges
  if (heroCallout && heroTitle && heroBody) {
    const activePlayerConsequence = consequences.find(c => c.playerId === AppState.game?.activePlayerId) || consequences[0];
    if (activePlayerConsequence && activePlayerConsequence.heroExplanation) {
      heroTitle.textContent = 'WHY DID THIS HAPPEN?';
      heroBody.innerHTML = `
        <strong>Cause & Effect Analysis:</strong><br />
        ${activePlayerConsequence.heroExplanation}<br />
        <span style="font-size: 0.8rem; color: var(--gold-light); display: block; margin-top: 6px;">
          Strategic Lesson: ${event.strategicLesson || 'Preparation changes future consequences.'}
        </span>
      `;
    }
  }

  modal.style.display = 'flex';
}

function dismissEventModal() {
  window.soundEngine?.playClick();
  hideEventModal();
  sendWs('DISMISS_EVENT');
}

function hideEventModal() {
  const modal = document.getElementById('event-modal');
  if (modal) modal.style.display = 'none';
}

// =============================================================================
// 5. RESULT PAGE BINDINGS & ANIMATED SCORES
// =============================================================================

function bindResultPage() {
  const lr = document.getElementById('learn-review');
  if (lr && window.LearnArena) lr.innerHTML = LearnArena.reviewHTML();
  if (!AppState.game) return;
  const game = AppState.game;
  const winner = game.winner;

  const winnerNameEl = document.getElementById('result-winner-name');
  const winnerPlayerEl = document.getElementById('result-winner-player');
  const reasonEl = document.getElementById('result-victory-reason');

  if (winnerNameEl && winner) winnerNameEl.textContent = winner.civilizationName;
  if (winnerPlayerEl && winner) winnerPlayerEl.textContent = `Leader: ${winner.name}`;
  if (reasonEl && winner) {
    reasonEl.textContent = `Prevailing through superior ${winner.scoreBreakdown ? 'balanced strategy and infrastructure resilience' : 'overall governance'}.`;
  }

  // Animated Countup for winner score
  if (winner) {
    animateScoreCounter('result-winner-score', winner.score || 0);

    const b = winner.scoreBreakdown || {};
    animateScoreCounter('cat-development', b.development || 0);
    animateScoreCounter('cat-efficiency', b.resourceEfficiency || 0);
    animateScoreCounter('cat-cultural', b.culturalDevelopment || 0);
    animateScoreCounter('cat-sustainability', b.sustainability || 0);
    animateScoreCounter('cat-adaptability', b.adaptability || 0);
    animateScoreCounter('cat-trade', b.trade || 0);
  }

  // LIME / mistake reports for every player
  const limeHost = document.getElementById('lime-player-reports');
  if (limeHost) {
    const reports = game.explainability || [];
    limeHost.innerHTML = reports.map(report => {
      const color = game.players.find(p => p.id === report.playerId)?.badge?.color || '#D4AF37';
      const positives = (report.topPositiveFactors || []).slice(0, 3);
      const negatives = (report.topNegativeFactors || []).slice(0, 4);
      const mistakes = report.mistakes || [];
      return `
        <article class="lime-player-card" style="--lime-player-color:${color}">
          <div class="lime-player-head">
            <div>
              <div class="eyebrow">PLAYER ${report.playerId} · LIME LOCAL EXPLANATION</div>
              <h3>${escapeHtml(report.civilizationName)}</h3>
              <span>Leader: ${escapeHtml(report.playerName)} · Final score ${report.finalScore}/100</span>
            </div>
            <div class="lime-fidelity">Fidelity<br><b>${Math.round((report.fidelity || 0) * 100)}%</b></div>
          </div>
          <p class="lime-recommendation">💡 ${escapeHtml(report.recommendation)}</p>
          <div class="lime-columns">
            <div>
              <h4>⬆ Helped the score</h4>
              ${positives.length ? positives.map(f => `<div class="lime-factor positive"><span>${escapeHtml(f.label)}</span><b>+${Math.abs(f.contribution).toFixed(1)}</b></div>`).join('') : '<div class="lime-empty">No strong positive factor.</div>'}
            </div>
            <div>
              <h4>⬇ Hurt the score</h4>
              ${negatives.length ? negatives.map(f => `<div class="lime-factor negative"><span>${escapeHtml(f.label)}</span><b>-${Math.abs(f.contribution).toFixed(1)}</b></div>`).join('') : '<div class="lime-empty">No strong negative factor.</div>'}
            </div>
          </div>
          <div class="mistake-list">
            <h4>🎯 Mistakes to fix next game</h4>
            ${mistakes.length ? mistakes.map(m => `<div class="mistake-item ${m.severity || 'medium'}"><span>${m.severity === 'high' ? '🔴' : '🟠'}</span><div><b>${escapeHtml(m.title)}</b><p>${escapeHtml(m.detail)}</p></div></div>`).join('') : '<div class="mistake-item low"><span>✅</span><div><b>No major mistakes detected</b><p>Keep the same strategic discipline.</p></div></div>'}
          </div>
        </article>`;
    }).join('');
    if (!reports.length) {
      limeHost.innerHTML = '<div class="lime-empty large">LIME analysis becomes available when the game reaches completion.</div>';
    }
  }

  // Leaderboard Rankings
  const rankingsList = document.getElementById('result-rankings-list');
  if (rankingsList && game.rankings) {
    rankingsList.innerHTML = game.rankings.map(r => {
      const p = r.player;
      const medals = ['🥇', '🥈', '🥉', '4️⃣'];
      const medal = medals[r.rank - 1] || '•';
      return `
        <div style="display: flex; justify-content: space-between; align-items: center; padding: 12px 16px; border-radius: 8px; background: rgba(255,255,255,0.04); border-left: 4px solid ${p.badge?.color || '#D4AF37'};">
          <div style="display: flex; align-items: center; gap: 12px;">
            <span style="font-size: 1.4rem;">${medal}</span>
            <div>
              <strong style="font-size: 1rem; color: ${r.isWinner ? 'var(--gold-light)' : 'var(--text-primary)'};">${p.civilizationName}</strong>
              <div style="font-size: 0.78rem; color: var(--text-muted);">${p.name}</div>
            </div>
          </div>
          <span style="font-family: var(--font-mono); font-size: 1.4rem; font-weight: 700; color: var(--gold-light);">
            ${p.score} <span style="font-size: 0.8rem; color: var(--text-muted);">PTS</span>
          </span>
        </div>
      `;
    }).join('');
  }

  // Achievements
  const achList = document.getElementById('result-achievements-list');
  if (achList && winner && winner.achievements) {
    if (winner.achievements.length === 0) {
      achList.innerHTML = '<span style="font-size: 0.85rem; color: var(--text-muted);">No specialized badges unlocked.</span>';
    } else {
      achList.innerHTML = winner.achievements.map(a => `
        <div style="background: rgba(212,175,55,0.12); border: 1px solid var(--border-gold); padding: 8px 14px; border-radius: 20px; font-size: 0.82rem;">
          🏆 <strong>${a.title}</strong>: ${a.desc}
        </div>
      `).join('');
    }
  }
}

function animateScoreCounter(elementId, finalScore) {
  const el = document.getElementById(elementId);
  if (!el) return;
  let current = 0;
  const step = Math.max(1, Math.floor(finalScore / 25));
  const timer = setInterval(() => {
    current += step;
    if (current >= finalScore) {
      current = finalScore;
      clearInterval(timer);
    }
    el.textContent = current;
  }, 35);
}

function handlePlayAgain() {
  window.soundEngine?.playClick();
  fetch('/api/game/reset', { method: 'POST' })
    .then(() => navigateTo('start'));
}

// =============================================================================
// 6. BUILD CATALOG & TRADE MODALS
// =============================================================================

function openBuildModal() {
  window.soundEngine?.playClick();
  const modal = document.getElementById('build-modal');
  const grid = document.getElementById('build-catalog-grid');
  if (!modal || !grid || !AppState.game) return;

  const activePlayer = AppState.game.players.find(p => p.id === AppState.game.activePlayerId);
  const catalog = AppState.game.buildingsCatalog || [];

  grid.innerHTML = catalog.map(b => {
    const isBuilt = activePlayer?.buildings?.[b.id];
    let canAfford = true;
    if (activePlayer && b.cost) {
      for (const [res, cost] of Object.entries(b.cost)) {
        if ((activePlayer.resources[res] || 0) < cost) canAfford = false;
      }
    }

    const costBadges = Object.entries(b.cost)
      .filter(([_, amt]) => amt > 0)
      .map(([res, amt]) => `${res}: ${amt}`)
      .join(', ');

    return `
      <div class="card" style="padding: 16px; border-color: ${isBuilt ? '#48BB78' : 'var(--border-gold)'};">
        <div style="display: flex; gap: 12px; align-items: center; margin-bottom: 10px;">
          <img src="assets/buildings/${b.icon}.svg" style="width: 50px; height: 50px;" />
          <div>
            <h4 class="font-display" style="font-size: 1.05rem; color: var(--gold-light);">${b.name}</h4>
            <div style="font-size: 0.72rem; color: var(--text-muted);">${b.hindiName || ''}</div>
          </div>
        </div>
        <p style="font-size: 0.8rem; color: var(--text-secondary); margin-bottom: 10px;">${b.concept}</p>
        <div style="font-size: 0.78rem; color: var(--gold-light); margin-bottom: 12px;">Cost: ${costBadges}</div>
        ${isBuilt ? `
          <div class="plot-badge-active">✓ ALREADY BUILT</div>
        ` : `
          <button type="button" class="btn btn-primary" style="width: 100%; padding: 8px;" ${!canAfford ? 'disabled' : ''} onclick="triggerBuild('${b.id}'); closeModal('build-modal');">
            ${canAfford ? '🔨 BUILD NOW' : 'INSUFFICIENT RESOURCES'}
          </button>
        `}
      </div>
    `;
  }).join('');

  modal.style.display = 'flex';
}

function openTradeModal() {
  window.soundEngine?.playClick();
  const modal = document.getElementById('trade-modal');
  const targetSelect = document.getElementById('trade-target-player');
  if (!modal || !AppState.game) return;

  if (targetSelect && AppState.game.players) {
    targetSelect.innerHTML = AppState.game.players
      .filter(p => p.id !== AppState.game.activePlayerId)
      .map(p => `<option value="${p.id}">${p.civilizationName} (${p.name})</option>`)
      .join('');
  }

  modal.style.display = 'flex';
}

function switchTradeTab(tab) {
  AppState.activeTradeTab = tab;
  window.soundEngine?.playClick();
  const pTab = document.getElementById('trade-tab-player-content');
  const cTab = document.getElementById('trade-tab-caravan-content');
  if (tab === 'player') {
    pTab.style.display = 'block';
    cTab.style.display = 'none';
  } else {
    pTab.style.display = 'none';
    cTab.style.display = 'block';
  }
}

function submitPlayerTrade() {
  const targetId = document.getElementById('trade-target-player')?.value;
  const offerRes = document.getElementById('trade-offer-res')?.value;
  const offerAmt = parseInt(document.getElementById('trade-offer-amt')?.value, 10) || 1;
  const reqRes = document.getElementById('trade-req-res')?.value;
  const reqAmt = parseInt(document.getElementById('trade-req-amt')?.value, 10) || 1;

  sendWs('ACTION', {
    playerId: AppState.game.activePlayerId,
    actionType: 'TRADE_PROPOSE',
    payload: {
      toPlayerId: parseInt(targetId, 10),
      offer: { [offerRes]: offerAmt },
      request: { [reqRes]: reqAmt }
    }
  });

  closeModal('trade-modal');
}

function submitCaravanTrade() {
  const giveRes = document.getElementById('caravan-give-res')?.value;
  const getRes = document.getElementById('caravan-get-res')?.value;

  sendWs('ACTION', {
    playerId: AppState.game.activePlayerId,
    actionType: 'CARAVAN_TRADE',
    payload: { giveResource: giveRes, getResource: getRes, amount: 1 }
  });

  closeModal('trade-modal');
}

// =============================================================================
// 7. QUICK DEMO (CAUSE & EFFECT WALKTHROUGH)
// =============================================================================

function startHeroDemo() {
  window.soundEngine?.playClick();
  AppState.demoStep = 1;
  const modal = document.getElementById('hero-demo-modal');
  if (modal) modal.style.display = 'flex';
  executeDemoStep(1);
}

async function executeDemoStep(step) {
  try {
    const res = await fetch('/api/demo/step', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ step })
    });
    const data = await res.json();
    if (data.success) {
      AppState.game = data.state;
      renderDemoStepUI(step, data.result?.heroExplanation || data.result);
    }
  } catch (err) {
    console.error('Demo step failed:', err);
  }
}

function renderDemoStepUI(step, explanation) {
  const title = document.getElementById('demo-step-title');
  const desc = document.getElementById('demo-step-desc');
  const visual = document.getElementById('demo-step-visual');
  const btn = document.getElementById('btn-next-demo-step');

  if (step === 1) {
    if (title) title.textContent = 'Step 1: Civilizations Initialized';
    if (desc) desc.textContent = 'Two civilizations begin with balanced resources. Player 1 is about to physically place and scan a Water System.';
    if (visual) {
      visual.innerHTML = `
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
          <div style="background: rgba(212,175,55,0.1); padding: 12px; border-radius: 8px;">
            <strong>Player 1 (Hardware / Physical)</strong><br />
            Indus Builders • Resources: 🌾 5, 💧 5, 🪨 5, 🪙 5
          </div>
          <div style="background: rgba(49,130,206,0.1); padding: 12px; border-radius: 8px;">
            <strong>Player 2 (Digital Rival)</strong><br />
            Vedic Pioneers • Resources: 🌾 5, 💧 5, 🪨 5, 🪙 5
          </div>
        </div>
      `;
    }
    if (btn) btn.textContent = 'STEP 2: SCAN WATER SYSTEM ➔';
  } else if (step === 2) {
    window.soundEngine?.playBuild();
    if (title) title.textContent = 'Step 2: Physical Water System Scanned';
    if (desc) desc.textContent = 'Player 1 scanned RFID: WATER_SYSTEM. Cost deducted (2 Materials, 1 Wealth). The system records traditional stepwell infrastructure.';
    if (visual) {
      visual.innerHTML = `
        <div style="background: rgba(49,130,206,0.15); border-left: 4px solid #3182CE; padding: 14px; border-radius: 6px;">
          <strong style="color: #63B3ED;">✓ STATE UPDATED:</strong><br />
          Indus Builders built: <strong>WATER SYSTEM (Stepwells / Baolis)</strong>.<br />
          Remaining Materials: 3, Wealth: 4.<br />
          Vedic Pioneers built: <em>None (Unprotected)</em>.
        </div>
      `;
    }
    if (btn) btn.textContent = 'STEP 3: TRIGGER DROUGHT CRISIS ➔';
  } else if (step === 3) {
    window.soundEngine?.playDrought();
    if (title) title.textContent = 'Step 3: Climatic Crisis — Severe Drought!';
    if (desc) desc.textContent = 'The monsoon fails. The Consequence Engine now queries each civilization\'s infrastructure to calculate water loss.';
    if (visual) {
      visual.innerHTML = `
        <div style="background: rgba(229,62,62,0.15); border-left: 4px solid #E53E3E; padding: 14px; border-radius: 6px;">
          <strong style="color: #FC8181;">⚠ EVALUATING DROUGHT IMPACT:</strong><br />
          Without Water Infrastructure: Standard drought penalty is <strong>-3 Water</strong>.<br />
          With Water Infrastructure: Stepwells buffer reserves, cutting loss to <strong>-1 Water</strong>!
        </div>
      `;
    }
    if (btn) btn.textContent = 'STEP 4: REVEAL PROOF & EXPLANATION ➔';
  } else if (step === 4) {
    window.soundEngine?.playFestival();
    if (title) title.textContent = 'HERO PROOF: PREPARATION CHANGES SURVIVAL';
    if (desc) desc.textContent = 'The core innovation of CHAKRA-BHARAT: physical decisions directly shape future consequences.';
    if (visual) {
      visual.innerHTML = `
        <div style="display: flex; flex-direction: column; gap: 12px;">
          <div style="background: rgba(72,187,120,0.15); border-left: 4px solid #48BB78; padding: 12px; border-radius: 6px;">
            <strong style="color: #68D391;">Player 1 (Indus Builders) WITH Water System:</strong><br />
            Suffered only <strong>-1 Water</strong>! (Current Water: ${AppState.game?.players[0]?.resources.water})<br />
            <em>"Traditional stepwells stored monsoon runoff and preserved life."</em>
          </div>
          <div style="background: rgba(229,62,62,0.15); border-left: 4px solid #E53E3E; padding: 12px; border-radius: 6px;">
            <strong style="color: #FC8181;">Player 2 (Vedic Pioneers) WITHOUT Water System:</strong><br />
            Suffered full dehydration of <strong>-3 Water</strong>! (Current Water: ${AppState.game?.players[1]?.resources.water})<br />
            <em>"Open ponds evaporated completely under extreme heat."</em>
          </div>
        </div>
      `;
    }
    if (btn) {
      btn.textContent = 'ENTER FULL GAMEPLAY ⚔';
      btn.onclick = () => {
        closeModal('hero-demo-modal');
        navigateTo('game');
      };
    }
  }
}

function advanceDemoStep() {
  window.soundEngine?.playClick();
  AppState.demoStep++;
  executeDemoStep(AppState.demoStep);
}

// =============================================================================
// 8. VIRTUAL HARDWARE SIMULATOR & TELEMETRY
// =============================================================================

function toggleVirtualTray() {
  AppState.isVirtualTrayOpen = !AppState.isVirtualTrayOpen;
  const body = document.getElementById('virtual-tray-body');
  const indicator = document.getElementById('tray-arrow-indicator');
  if (body) body.style.display = AppState.isVirtualTrayOpen ? 'flex' : 'none';
  if (indicator) indicator.textContent = AppState.isVirtualTrayOpen ? '▼ COLLAPSE' : '▲ EXPAND';
}

function simulateRfid(buildingId) {
  window.soundEngine?.playClick();
  const playerSelect = document.getElementById('virtual-target-player');
  const playerId = playerSelect ? parseInt(playerSelect.value, 10) : 1;

  const raw = `PLAYER=${playerId};ACTION=BUILD;ITEM=${buildingId}`;
  updateVirtualSerialLog(`TX: ${raw}`);

  sendWs('HARDWARE_COMMAND', { command: raw });
}

function simulateButton(buttonType) {
  window.soundEngine?.playClick();
  const playerSelect = document.getElementById('virtual-target-player');
  const playerId = playerSelect ? parseInt(playerSelect.value, 10) : 1;

  const raw = `PLAYER=${playerId};ACTION=BUTTON;ITEM=${buttonType}`;
  updateVirtualSerialLog(`TX: ${raw}`);

  sendWs('HARDWARE_COMMAND', { command: raw });
}

function updateVirtualSerialLog(text) {
  const logEl = document.getElementById('virtual-serial-log');
  if (logEl) logEl.textContent = text;
}

function updateSmartBoardTelemetry(telemetry) {
  if (!telemetry) return;

  const oled1 = document.getElementById('oled-line-1');
  const oled2 = document.getElementById('oled-line-2');
  const lastAction = document.getElementById('hw-last-action');

  if (oled1 && telemetry.oled) oled1.textContent = telemetry.oled.line1 || 'CHAKRA-BHARAT';
  if (oled2 && telemetry.oled) oled2.textContent = telemetry.oled.line2 || 'READY';
  if (lastAction && telemetry.lastAction) {
    lastAction.textContent = telemetry.lastAction.action ? `${telemetry.lastAction.action} (${telemetry.lastAction.item || 'BTN'})` : 'None';
  }
}

function updateHardwareStatusUI(hwStatus) {
  if (!hwStatus) return;
  const text = document.getElementById('hw-status-text');
  const dot = document.getElementById('hw-status-dot');

  if (text && dot) {
    if (hwStatus.isConnected) {
      text.textContent = `ESP32 CONNECTED (${hwStatus.portName})`;
      dot.className = 'status-dot active';
    } else {
      text.textContent = 'VIRTUAL HARDWARE MODE';
      dot.className = 'status-dot virtual';
    }
  }
}

async function pollHardwareStatus() {
  try {
    const res = await fetch('/api/hardware/status');
    const data = await res.json();
    if (data.success) {
      updateHardwareStatusUI(data.status);
      if (data.status?.telemetry) {
        updateSmartBoardTelemetry(data.status.telemetry);
      }
    }
  } catch {
    // Silent fail
  }
}

// =============================================================================
// 9. MODAL HELPERS & UTILITIES
// =============================================================================

function closeModal(modalId) {
  window.soundEngine?.playClick();
  const modal = document.getElementById(modalId);
  if (modal) modal.style.display = 'none';
}

function openSmartBoardModal() {
  window.soundEngine?.playClick();
  const modal = document.getElementById('smartboard-modal');
  if (modal) modal.style.display = 'flex';
}

function openHowToPlayModal() {
  window.soundEngine?.playClick();
  const modal = document.getElementById('howtoplay-modal');
  if (modal) modal.style.display = 'flex';
}

function toggleAudio() {
  const isMuted = window.soundEngine?.toggleMute();
  const btn = document.getElementById('btn-audio-toggle');
  if (btn) {
    btn.textContent = isMuted ? '🔇 AUDIO OFF' : '🔊 AUDIO ON';
  }
}

function showToast(message) {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `<span>☸</span><span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

async function fetchGameState() {
  try {
    const res = await fetch('/api/game/state');
    const data = await res.json();
    if (data.success) {
      AppState.game = data.state;
      renderActivePage();
    }
  } catch (err) {
    console.error('Failed to fetch state:', err);
  }
}


// ---- How-to-play video ----
function openVideoModal() {
  window.soundEngine?.playClick();
  const m = document.getElementById('video-modal'), v = document.getElementById('how-video');
  if (m) m.style.display = 'flex';
  if (v) { v.currentTime = 0; v.play().catch(() => {}); }
}
function closeVideoModal() {
  const m = document.getElementById('video-modal'), v = document.getElementById('how-video');
  if (v) v.pause();
  if (m) m.style.display = 'none';
}
