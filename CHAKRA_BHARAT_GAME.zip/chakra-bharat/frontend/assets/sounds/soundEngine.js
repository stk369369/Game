/**
 * CHAKRA-BHARAT: Procedural Web Audio Engine
 * Zero external audio files required! Generates authentic, responsive soundscapes
 * using the browser's native Web Audio API synthesizer.
 */

class SoundEngine {
  constructor() {
    this.ctx = null;
    this.isMuted = false;
  }

  init() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (AudioContext) {
        this.ctx = new AudioContext();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  toggleMute() {
    this.isMuted = !this.isMuted;
    return this.isMuted;
  }

  playTone(freq, duration = 0.2, type = 'sine', gainVal = 0.2) {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, this.ctx.currentTime);

      gain.gain.setValueAtTime(gainVal, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc.stop(this.ctx.currentTime + duration);
    } catch {
      // Audio autoplay policy guard
    }
  }

  playClick() {
    this.playTone(600, 0.04, 'triangle', 0.1);
  }

  playBuild() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    // Ascending Veena / Chime Harmonic Triad
    const now = this.ctx.currentTime;
    const notes = [440, 554.37, 659.25, 880]; // A major
    notes.forEach((freq, i) => {
      setTimeout(() => {
        this.playTone(freq, 0.4, 'sine', 0.18);
      }, i * 80);
    });
  }

  playCoins() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    // Metallic coin clatter
    this.playTone(1800, 0.08, 'square', 0.08);
    setTimeout(() => this.playTone(2200, 0.12, 'square', 0.09), 60);
    setTimeout(() => this.playTone(2600, 0.15, 'sine', 0.1), 120);
  }

  playDrought() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    // Descending tension warning
    const now = this.ctx.currentTime;
    const notes = [320, 290, 240, 210];
    notes.forEach((freq, i) => {
      setTimeout(() => {
        this.playTone(freq, 0.4, 'sawtooth', 0.15);
      }, i * 140);
    });
  }

  playMonsoon() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    // Soothing pentatonic stream
    const notes = [523.25, 587.33, 659.25, 783.99, 880];
    notes.forEach((freq, i) => {
      setTimeout(() => {
        this.playTone(freq, 0.35, 'sine', 0.12);
      }, i * 70);
    });
  }

  playFestival() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    // Joyful celebration bell fanfare
    const chord = [523.25, 659.25, 783.99, 1046.5];
    chord.forEach((freq, i) => {
      setTimeout(() => {
        this.playTone(freq, 0.6, 'triangle', 0.15);
      }, i * 90);
    });
  }

  playVictory() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    // Grand imperial fanfare
    const notes = [440, 440, 440, 587.33, 659.25, 880];
    const delays = [0, 150, 300, 450, 700, 950];
    notes.forEach((freq, i) => {
      setTimeout(() => {
        this.playTone(freq, 0.5, 'triangle', 0.22);
      }, delays[i]);
    });
  }

  playError() {
    this.playTone(180, 0.25, 'sawtooth', 0.15);
  }
}

// Global instance
window.soundEngine = new SoundEngine();
