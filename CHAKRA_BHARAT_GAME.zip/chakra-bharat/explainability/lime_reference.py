"""
CHAKRA-BHARAT — Optional Python LIME reference implementation.

This mirrors the dependency-free JavaScript explainer shipped in the Node game.
It is intentionally standard-library-only so the game remains runnable without
installing an ML stack. For research/demo use, the algorithm can be replaced
with the `lime` package while preserving the JSON output contract.
"""
import json, math, random, sys

FEATURES = [
    "buildingsBuilt","waterSystem","farm","market","fort","tradesCompleted",
    "collections","specialActions","negativeEventsSurvived","protectedEvents",
    "festivalCount","balancedResources","zeroResources","failedActions","failedTrades",
    "unprotectedCrises","lateInfrastructure"
]

def predict_score(f):
    built = min(4, int(f.get("buildingsBuilt", 0)))
    development = built * 5 + (5 if built == 4 else 0)
    zero = int(f.get("zeroResources", 0))
    efficiency = (6 if zero == 0 else 3 if zero == 1 else 0)
    stock = 20 + int(f.get("balancedResources", 0)) + built * 2 + int(f.get("tradesCompleted", 0))*2
    efficiency = min(20, efficiency + min(14, math.floor(stock * .7)))
    efficiency = max(0, efficiency - min(4, int(f.get("failedActions",0))))
    cultural = min(15, int(f.get("specialActions",0))*2 + int(f.get("festivalCount",0))*5)
    sustainability = min(15, (10 if f.get("waterSystem") else 0) + (5 if f.get("balancedResources",0)>=3 else 2))
    adaptability = min(15, int(f.get("protectedEvents",0))*6 + (4 if f.get("fort") else 0) + min(5, int(f.get("negativeEventsSurvived",0))*2))
    adaptability = max(0, adaptability - min(4, int(f.get("unprotectedCrises",0))*2))
    trade = min(10, (5 if f.get("market") else 0) + min(5, int(f.get("tradesCompleted",0))*2 + (3 if f.get("market") else 0)))
    trade = max(0, trade - min(2, int(f.get("failedTrades",0))))
    return development+efficiency+cultural+sustainability+adaptability+trade

def explain(features, samples=220, seed=7):
    rng=random.Random(seed)
    base=[float(features.get(k,0)) for k in FEATURES]
    rows=[[1.0]+[x/10 for x in base]]
    y=[predict_score(features)]
    w=[1.0]
    for _ in range(samples):
        pert={}
        for i,k in enumerate(FEATURES):
            x=base[i]
            if x>0 and rng.random() < .18+rng.random()*.45:
                pert[k]=0
            else:
                pert[k]=max(0, x-int(rng.random()*min(2,x))) if x>1 else x
        dist=math.sqrt(sum(((base[i]-pert[k])/10)**2 for i,k in enumerate(FEATURES)))
        rows.append([1.0]+[pert[k]/10 for k in FEATURES])
        y.append(predict_score(pert))
        w.append(math.exp(-(dist*dist)/.75))

    # weighted normal equations
    d=len(rows[0])
    A=[[0.0]*d for _ in range(d)]
    b=[0.0]*d
    for row,yy,ww in zip(rows,y,w):
        for i in range(d):
            b[i]+=ww*row[i]*yy
            for j in range(d): A[i][j]+=ww*row[i]*row[j]
    for i in range(d): A[i][i]+=.35

    for col in range(d):
        pivot=max(range(col,d),key=lambda r:abs(A[r][col]))
        A[col],A[pivot]=A[pivot],A[col]; b[col],b[pivot]=b[pivot],b[col]
        div=A[col][col] or 1e-9
        for j in range(col,d): A[col][j]/=div
        b[col]/=div
        for r in range(d):
            if r==col: continue
            factor=A[r][col]
            for j in range(col,d): A[r][j]-=factor*A[col][j]
            b[r]-=factor*b[col]
    contributions=[
        {"feature":k,"value":base[i],"weight":b[i+1],"contribution":b[i+1]*(base[i]/10)}
        for i,k in enumerate(FEATURES)
    ]
    contributions.sort(key=lambda x:abs(x["contribution"]),reverse=True)
    return {"prediction":predict_score(features),"contributions":contributions}

if __name__=="__main__":
    data=json.load(sys.stdin)
    print(json.dumps(explain(data), indent=2))
