'use strict';
/* Built-in C / C++ engine (teaching subset). Used automatically when gcc/g++ is not installed.
   Supports: int/char/float/double/bool/string/vector, arrays, pointers to variables, functions & recursion,
   if/for/while/do/switch, printf/scanf/puts/getchar, cout/cin/endl/fixed/setprecision, math & string helpers. */
class Err extends Error {}
class Fl { constructor(v) { this.v = v; } }
class Ctl { constructor(k, v) { this.k = k; this.v = v; } }
const WORDS = new Set(['int', 'long', 'short', 'char', 'float', 'double', 'unsigned', 'signed', 'void', 'bool', 'string', 'auto', 'const', 'static', 'size_t', 'vector']);
const unesc = s => s.replace(/\\(x[0-9a-fA-F]{2}|.)/g, (m, c) => ({ n: '\n', t: '\t', r: '\r', 0: '\0', a: '\x07', '\\': '\\', '"': '"', "'": "'" })[c] ?? (c[0] === 'x' ? String.fromCharCode(parseInt(c.slice(1), 16)) : c));

function lex(src, defs = {}) {
  src = src.replace(/\/\*[\s\S]*?\*\//g, m => m.replace(/[^\n]/g, ' ')).replace(/\/\/[^\n]*/g, '');
  src = src.split('\n').map(l => { const m = l.match(/^\s*#\s*define\s+(\w+)\s+(.+)$/); if (m) { defs[m[1]] = m[2].trim(); return ''; } return /^\s*#/.test(l) ? '' : l; }).join('\n');
  const re = /\s*(?:(0[xX][0-9a-fA-F]+|(?:\d+\.\d*|\.\d+|\d+)(?:[eE][+-]?\d+)?[fFlLuU]*)|([A-Za-z_]\w*)|"((?:\\.|[^"\\\n])*)"|'((?:\\.|[^'\\\n])+)'|(<<=|>>=|<<|>>|<=|>=|==|!=|&&|\|\||\+\+|--|\+=|-=|\*=|\/=|%=|&=|\|=|\^=|->|::|[-+*\/%=<>!&|^~?:;,.(){}\[\]]))/y;
  let T = [], line = 1, pos = 0;
  while (pos < src.length) {
    re.lastIndex = pos; const m = re.exec(src);
    if (!m) { if (/^\s*$/.test(src.slice(pos))) break; throw new Err(`line ${line}: error: stray '${src.slice(pos).trim()[0]}' in program`); }
    line += (m[0].match(/\n/g) || []).length; pos = re.lastIndex;
    if (m[1] !== undefined) { const hex = /^0[xX]/.test(m[1]), t = m[1].replace(/[fFlLuU]+$/, ''); T.push({ t: 'num', v: hex ? parseInt(t, 16) : parseFloat(t), f: !hex && (/[.eE]/.test(t) || /f$/i.test(m[1])), line }); }
    else if (m[2] !== undefined) { if (defs[m[2]] !== undefined) lex(defs[m[2]], {}).forEach(x => T.push({ ...x, line })); else T.push({ t: 'id', v: m[2], line }); }
    else if (m[3] !== undefined) T.push({ t: 'str', v: unesc(m[3]), line });
    else if (m[4] !== undefined) T.push({ t: 'chr', v: unesc(m[4]).charCodeAt(0), line });
    else T.push({ t: 'op', v: m[5], line });
  }
  const R = [];
  for (let i = 0; i < T.length; i++) {
    if (T[i].v === 'std' && T[i + 1] && T[i + 1].v === '::') { i++; continue; }
    if (T[i].v === 'using' && T[i + 1] && T[i + 1].v === 'namespace') { while (T[i] && T[i].v !== ';') i++; continue; }
    R.push(T[i]);
  }
  return R;
}

function parse(T) {
  let p = 0;
  const EOF = () => ({ t: 'eof', v: 'end of file', line: T.length ? T[T.length - 1].line : 1 });
  const pk = (o = 0) => T[p + o] || EOF(), nx = () => T[p++] || EOF();
  const isO = (v, o = 0) => pk(o).t === 'op' && pk(o).v === v;
  const fail = m => { throw new Err(`line ${pk().line}: error: ${m}`); };
  const eat = v => isO(v) ? (p++, true) : false;
  const need = v => { if (!eat(v)) fail(`expected '${v}' before '${pk().v}'`); };
  const isTy = (o = 0) => pk(o).t === 'id' && WORDS.has(pk(o).v);
  function pType() {
    const ws = []; let el = null;
    while (isTy()) { const w = nx().v; ws.push(w); if (w === 'vector') { need('<'); let d = 1; el = pk().v; while (d > 0) { const t = nx(); if (t.t === 'eof') fail('unterminated template'); if (t.v === '<') d++; else if (t.v === '>') d--; else if (t.v === '>>') d -= 2; } } }
    let k = 'int';
    if (ws.includes('vector')) k = 'vector'; else if (ws.includes('string')) k = 'string'; else if (ws.includes('double') || ws.includes('float')) k = 'float'; else if (ws.includes('char')) k = 'char'; else if (ws.includes('bool')) k = 'bool'; else if (ws.includes('void')) k = 'void'; else if (ws.includes('auto')) k = 'auto';
    let ptr = 0; while (eat('*')) ptr++;
    return { k, ptr, el };
  }
  const PREC = { '||': 1, '&&': 2, '|': 3, '^': 4, '&': 5, '==': 6, '!=': 6, '<': 7, '>': 7, '<=': 7, '>=': 7, '<<': 8, '>>': 8, '+': 9, '-': 9, '*': 10, '/': 10, '%': 10 };
  const ASG = new Set(['=', '+=', '-=', '*=', '/=', '%=', '&=', '|=', '^=', '<<=', '>>=']);
  const pArgs = () => { const a = []; if (!eat(')')) { do a.push(pExpr()); while (eat(',')); need(')'); } return a; };
  function pExpr() { const l = pTern(); if (pk().t === 'op' && ASG.has(pk().v)) { const op = nx().v; return ['as', op, l, pExpr()]; } return l; }
  function pTern() { const c = pBin(1); if (eat('?')) { const a = pExpr(); need(':'); return ['tern', c, a, pTern()]; } return c; }
  function pBin(mp) { let l = pUn(); for (;;) { const t = pk(); const pr = t.t === 'op' && PREC[t.v]; if (!pr || pr < mp) return l; p++; l = ['bin', t.v, l, pBin(pr + 1)]; } }
  function pUn() {
    const t = pk();
    if (t.t === 'op') {
      if (['-', '+', '!', '~', '*', '&'].includes(t.v)) { p++; return ['un', t.v, pUn()]; }
      if (t.v === '++' || t.v === '--') { p++; return ['pre', t.v, pUn()]; }
      if (t.v === '(' && isTy(1)) { p++; const ty = pType(); need(')'); return ['cast', ty, pUn()]; }
    }
    if (t.t === 'id' && t.v === 'sizeof') { p++; let n = 4; if (eat('(')) { if (isTy()) { const ty = pType(); n = ty.ptr ? 8 : ty.k === 'char' || ty.k === 'bool' ? 1 : ty.k === 'float' ? 8 : 4; } else pExpr(); need(')'); } else pUn(); return ['num', n, false]; }
    return pPost();
  }
  function pPost() {
    let e = pPrim();
    for (;;) {
      if (eat('[')) { const i = pExpr(); need(']'); e = ['idx', e, i]; }
      else if (isO('(') && e[0] === 'id') { p++; e = ['call', e[1], pArgs()]; }
      else if (eat('.')) { const n = nx().v; e = ['meth', e, n, eat('(') ? pArgs() : []]; }
      else if (isO('++') || isO('--')) e = ['post', nx().v, e];
      else return e;
    }
  }
  function pPrim() {
    const t = nx();
    if (t.t === 'num') return ['num', t.v, t.f];
    if (t.t === 'str') { let s = t.v; while (pk().t === 'str') s += nx().v; return ['str', s]; }
    if (t.t === 'chr') return ['chr', t.v];
    if (t.t === 'id') return ['id', t.v];
    if (t.t === 'op' && t.v === '(') { const e = pExpr(); need(')'); return e; }
    p--; fail(`unexpected '${t.v}'`);
  }
  function pList() { need('{'); const a = []; while (!eat('}')) { a.push(isO('{') ? pList() : pExpr()); if (!eat(',')) { need('}'); break; } } return ['list', a]; }
  function pDecl() {
    const ty = pType(), ds = [];
    do {
      while (eat('*'));
      const nt = nx(); if (nt.t !== 'id') fail(`expected identifier before '${nt.v}'`);
      const dims = []; while (eat('[')) { dims.push(isO(']') ? null : pExpr()); need(']'); }
      let init = null;
      if (eat('=')) init = isO('{') ? pList() : pExpr(); else if (eat('(')) init = ['ctor', pArgs()];
      ds.push({ name: nt.v, dims, init });
    } while (eat(','));
    need(';'); return ['decl', ty, ds];
  }
  const pBlock = () => { const b = []; while (!eat('}')) { if (pk().t === 'eof') fail("expected '}' at end of input"); b.push(pStmt()); } return b; };
  function pStmt() {
    const t = pk();
    if (t.t === 'op') { if (t.v === '{') { p++; return ['block', pBlock()]; } if (t.v === ';') { p++; return ['block', []]; } }
    if (t.t === 'id') {
      switch (t.v) {
        case 'if': { p++; need('('); const c = pExpr(); need(')'); const a = pStmt(); let b = null; if (pk().v === 'else') { p++; b = pStmt(); } return ['if', c, a, b]; }
        case 'while': { p++; need('('); const c = pExpr(); need(')'); return ['while', c, pStmt()]; }
        case 'do': { p++; const b = pStmt(); if (pk().v !== 'while') fail("expected 'while' after do body"); p++; need('('); const c = pExpr(); need(')'); need(';'); return ['do', b, c]; }
        case 'for': {
          p++; need('(');
          if (isTy()) { const save = p, ty = pType(); if (pk().t === 'id' && isO(':', 1)) { const n = nx().v; p++; const coll = pExpr(); need(')'); return ['rfor', ty, n, coll, pStmt()]; } p = save; }
          let init = null; if (!eat(';')) { if (isTy()) init = pDecl(); else { const e = pExpr(); need(';'); init = ['expr', e]; } }
          let c = null; if (!eat(';')) { c = pExpr(); need(';'); }
          let st = null; if (!eat(')')) { st = pExpr(); need(')'); }
          return ['for', init, c, st, pStmt()];
        }
        case 'return': { p++; let e = null; if (!isO(';')) e = pExpr(); need(';'); return ['ret', e]; }
        case 'break': p++; need(';'); return ['brk'];
        case 'continue': p++; need(';'); return ['cont'];
        case 'switch': {
          p++; need('('); const e = pExpr(); need(')'); need('{'); const cs = [];
          while (!eat('}')) {
            let v = null; if (pk().v === 'case') { p++; v = pTern(); need(':'); } else if (pk().v === 'default') { p++; need(':'); } else fail("expected 'case' or 'default'");
            const b = []; while (!isO('}') && pk().v !== 'case' && pk().v !== 'default' && pk().t !== 'eof') b.push(pStmt());
            cs.push({ v, b });
          }
          return ['sw', e, cs];
        }
        case 'struct': case 'typedef': case 'enum': case 'class': case 'union': fail(`'${t.v}' needs a real compiler (install gcc/g++) - the built-in engine does not support it`);
      }
      if (isTy()) return pDecl();
    }
    const e = pExpr(); need(';'); return ['expr', e];
  }
  const fns = {}, globals = [];
  while (pk().t !== 'eof') {
    if (!isTy()) fail(`unexpected '${pk().v}' at top level`);
    const save = p, ty = pType(), nm = pk();
    if (nm.t === 'id' && isO('(', 1)) {
      p += 2; const ps = [];
      if (!eat(')')) {
        if (pk().v === 'void' && isO(')', 1)) p++;
        else do { const pt = pType(), ref = eat('&'), pn = pk().t === 'id' ? nx().v : '_'; let arr = false; while (eat('[')) { if (!isO(']')) pExpr(); need(']'); arr = true; } ps.push({ ty: pt, name: pn, ref, arr }); } while (eat(','));
        need(')');
      }
      if (eat(';')) continue;
      need('{'); fns[nm.v] = { ty, ps, body: pBlock() };
    } else { p = save; globals.push(pDecl()); }
  }
  return { fns, globals };
}

function run(code, stdin) {
  let prog;
  try { prog = parse(lex(code)); } catch (e) { if (e instanceof Err) return { ok: false, stdout: '', stderr: 'Compilation error:\n' + e.message }; throw e; }
  if (!prog.fns.main) return { ok: false, stdout: '', stderr: 'Compilation error:\nundefined reference to `main`' };
  const out = []; let outLen = 0, steps = 0, depth = 0, failbit = 0; const LIMIT = 4e6;
  const w = s => { outLen += s.length; if (outLen > 50000) throw new Err('Output limit exceeded'); out.push(s); };
  const COUT = { cout: 1 }, CIN = { cin: 1 }, ENDL = { endl: 1 }, FIXED = { fixed: 1 }, cs = { fixed: false, prec: 6 };
  const KW = { endl: ENDL, cout: COUT, cin: CIN, fixed: FIXED, true: 1, false: 0, NULL: 0, nullptr: 0, INT_MAX: 2147483647, INT_MIN: -2147483648, EOF: -1 };
  class Sc { constructor(par) { this.m = new Map(); this.par = par; } }
  const find = (sc, n) => { for (; sc; sc = sc.par) { const c = sc.m.get(n); if (c) return c; } return null; };
  const isN = v => typeof v === 'number' || v instanceof Fl;
  const num = v => { if (v instanceof Fl) return v.v; if (typeof v === 'number') return v; if (typeof v === 'string') return v.length ? v.charCodeAt(0) : 0; throw new Err('invalid operand (not a number)'); };
  const truth = v => v === CIN ? !failbit : isN(v) ? num(v) !== 0 : typeof v === 'string' ? v.length > 0 : !!v;
  const cstr = v => { if (typeof v === 'string') return v; if (Array.isArray(v)) { let s = ''; for (const c of v) { if (!c) break; s += String.fromCharCode(num(c)); } return s; } return ''; };
  const coerce = (ty, v) => { if (!ty || ty.ptr || !isN(v)) return v; switch (ty.k) { case 'int': return Math.trunc(num(v)) | 0; case 'char': return (Math.trunc(num(v)) & 255) << 24 >> 24; case 'float': return new Fl(num(v)); case 'bool': return num(v) ? 1 : 0; default: return v; } };
  const zero = ty => ty.ptr ? 0 : ty.k === 'float' ? new Fl(0) : ty.k === 'string' ? '' : ty.k === 'vector' ? [] : 0;
  const vecTy = ty => ({ k: ty.el === 'double' || ty.el === 'float' ? 'float' : ty.el === 'char' ? 'char' : ty.el === 'string' ? 'string' : 'int', ptr: 0 });
  const mk = (d, ty) => { if (!d.length) return zero(ty); const a = Array.from({ length: d[0] }, () => mk(d.slice(1), ty)); a.ty = ty; return a; };
  const gfmt = (x, p) => { if (x === 0) return '0'; const e = Math.floor(Math.log10(Math.abs(x))); if (e < -4 || e >= p) return x.toExponential(p - 1).replace(/\.?0+e/, 'e').replace(/e([+-])(\d)$/, 'e$10$2'); const s = x.toFixed(Math.max(0, p - 1 - e)); return s.includes('.') ? s.replace(/\.?0+$/, '') : s; };
  const arith = (op, a, b) => {
    if (typeof a === 'string' || typeof b === 'string') {
      const sa = typeof a === 'string' ? a : String.fromCharCode(num(a)), sb = typeof b === 'string' ? b : String.fromCharCode(num(b));
      switch (op) { case '+': return sa + sb; case '==': return +(sa === sb); case '!=': return +(sa !== sb); case '<': return +(sa < sb); case '>': return +(sa > sb); case '<=': return +(sa <= sb); case '>=': return +(sa >= sb); }
      throw new Err('invalid operands to string operator ' + op);
    }
    const fl = a instanceof Fl || b instanceof Fl, x = num(a), y = num(b); let r;
    switch (op) {
      case '+': r = x + y; break; case '-': r = x - y; break; case '*': r = fl ? x * y : Math.imul(x, y); break;
      case '/': if (!fl) { if (y === 0) throw new Err('Floating point exception: integer division by zero'); r = Math.trunc(x / y); } else r = x / y; break;
      case '%': if (y === 0) throw new Err('Floating point exception: modulo by zero'); r = x % y; break;
      case '<': return +(x < y); case '>': return +(x > y); case '<=': return +(x <= y); case '>=': return +(x >= y); case '==': return +(x === y); case '!=': return +(x !== y);
      case '&': return x & y; case '|': return x | y; case '^': return x ^ y; case '<<': return x << y; case '>>': return x >> y;
      default: throw new Err('bad operator ' + op);
    }
    return fl ? new Fl(r) : r | 0;
  };
  const fmt = (f, a) => { let ai = 0; return f.replace(/%([-+ 0#]*)(\d+|\*)?(?:\.(\d+))?(?:hh|h|ll|l|L|z)?([diuxXcsfFeEgGpo%])/g, (m, fl, wd, pr, cv) => {
    if (cv === '%') return '%'; if (wd === '*') wd = num(a[ai++]); const v = a[ai++]; if (v === undefined) throw new Err('too few arguments for printf'); let s;
    switch (cv) {
      case 'd': case 'i': s = String(Math.trunc(num(v))); break; case 'u': s = String(num(v) >>> 0); break;
      case 'x': s = (num(v) >>> 0).toString(16); break; case 'X': s = (num(v) >>> 0).toString(16).toUpperCase(); break; case 'o': s = (num(v) >>> 0).toString(8); break;
      case 'c': s = String.fromCharCode(num(v)); break; case 's': s = cstr(v); if (pr !== undefined) s = s.slice(0, +pr); break;
      case 'f': case 'F': s = num(v).toFixed(pr === undefined ? 6 : +pr); break;
      case 'e': case 'E': s = num(v).toExponential(pr === undefined ? 6 : +pr).replace(/e([+-])(\d)$/, 'e$10$2'); if (cv === 'E') s = s.toUpperCase(); break;
      case 'g': case 'G': s = gfmt(num(v), pr === undefined ? 6 : (+pr || 1)); break; default: s = '0x1000';
    }
    if ('dif'.includes(cv) && num(v) >= 0) { if (fl.includes('+')) s = '+' + s; else if (fl.includes(' ')) s = ' ' + s; }
    if (wd && s.length < +wd) { const W = +wd; if (fl.includes('-')) s = s.padEnd(W); else if (fl.includes('0') && cv !== 's' && cv !== 'c') { const sg = /^[+-]/.test(s) ? s[0] : ''; s = sg + s.slice(sg.length).padStart(W - sg.length, '0'); } else s = s.padStart(W); }
    return s; }); };
  const inp = { s: stdin || '', p: 0 };
  const skipWs = () => { while (inp.p < inp.s.length && /\s/.test(inp.s[inp.p])) inp.p++; };
  const readTok = re => { re.lastIndex = inp.p; const m = re.exec(inp.s); if (!m) return null; inp.p = re.lastIndex; return m[0]; };
  const RI = /[+-]?\d+/y, RF = /[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/y, RS = /\S+/y;
  const store = (d, v) => { if (d && d.ref) d.ref.v = coerce(d.ref.ty, v); else throw new Err('scanf expects a pointer (did you forget the & before the variable?)'); };
  const scanf = (f, args) => {
    let ai = 0, cnt = 0;
    for (let i = 0; i < f.length; i++) {
      const ch = f[i];
      if (/\s/.test(ch)) { skipWs(); continue; }
      if (ch !== '%') { if (inp.s[inp.p] === ch) inp.p++; else break; continue; }
      i++; while (/[\d.*hlLz]/.test(f[i])) i++; const cv = f[i];
      const dst = args[ai++];
      if (cv === 'c') { if (inp.p >= inp.s.length) break; store(dst, inp.s.charCodeAt(inp.p++)); cnt++; continue; }
      skipWs();
      if ('diu'.includes(cv)) { const t = readTok(RI); if (t === null) break; store(dst, parseInt(t, 10)); }
      else if ('feEgG'.includes(cv)) { const t = readTok(RF); if (t === null) break; store(dst, new Fl(parseFloat(t))); }
      else if (cv === 's') { const t = readTok(RS); if (t === null) break; if (Array.isArray(dst)) { const n = Math.min(t.length, dst.length - 1); for (let k = 0; k < n; k++) dst[k] = t.charCodeAt(k); dst[n] = 0; } else if (dst && dst.ref) dst.ref.v = t; else throw new Err('scanf %s needs a char array'); }
      else throw new Err(`unsupported scanf format %${cv}`);
      cnt++;
    }
    return cnt || (inp.p >= inp.s.length ? -1 : 0);
  };
  const cinRead = c => {
    skipWs(); const k = (c.ty || { k: 'int' }).k; let t;
    if (k === 'char') { if (inp.p >= inp.s.length) { failbit = 1; return; } c.v = inp.s.charCodeAt(inp.p++); return; }
    t = readTok(k === 'string' ? RS : k === 'float' ? RF : RI); if (t === null) { failbit = 1; return; }
    c.v = k === 'string' ? t : k === 'float' ? new Fl(parseFloat(t)) : parseInt(t, 10);
  };
  const sout = v => v instanceof Fl ? (cs.fixed ? v.v.toFixed(cs.prec) : gfmt(v.v, cs.prec || 6)) : typeof v === 'number' ? String(v) : cstr(v);
  const m1 = f => a => new Fl(f(num(a[0])));
  const BI = {
    printf: a => { const s = fmt(cstr(a[0]), a.slice(1)); w(s); return s.length; }, scanf: a => scanf(cstr(a[0]), a.slice(1)),
    puts: a => { w(cstr(a[0]) + '\n'); return 0; }, putchar: a => { w(String.fromCharCode(num(a[0]))); return num(a[0]); },
    getchar: () => inp.p < inp.s.length ? inp.s.charCodeAt(inp.p++) : -1,
    strlen: a => cstr(a[0]).length, strcmp: a => { const x = cstr(a[0]), y = cstr(a[1]); return x < y ? -1 : x > y ? 1 : 0; },
    strcpy: a => { const s = cstr(a[1]); for (let i = 0; i < s.length; i++) a[0][i] = s.charCodeAt(i); a[0][s.length] = 0; return 0; },
    strcat: a => { const s = cstr(a[0]), t = cstr(a[1]); for (let i = 0; i < t.length; i++) a[0][s.length + i] = t.charCodeAt(i); a[0][s.length + t.length] = 0; return 0; },
    abs: a => a[0] instanceof Fl ? new Fl(Math.abs(a[0].v)) : Math.abs(num(a[0])), labs: a => Math.abs(num(a[0])), fabs: m1(Math.abs),
    sqrt: m1(Math.sqrt), floor: m1(Math.floor), ceil: m1(Math.ceil), round: m1(Math.round), sin: m1(Math.sin), cos: m1(Math.cos), tan: m1(Math.tan), log: m1(Math.log), log10: m1(Math.log10), exp: m1(Math.exp),
    pow: a => new Fl(Math.pow(num(a[0]), num(a[1]))),
    max: a => arith('>', a[0], a[1]) ? a[0] : a[1], min: a => arith('<', a[0], a[1]) ? a[0] : a[1],
    toupper: a => String.fromCharCode(num(a[0])).toUpperCase().charCodeAt(0), tolower: a => String.fromCharCode(num(a[0])).toLowerCase().charCodeAt(0),
    isdigit: a => +/\d/.test(String.fromCharCode(num(a[0]))), isalpha: a => +/[A-Za-z]/.test(String.fromCharCode(num(a[0]))), isalnum: a => +/[A-Za-z0-9]/.test(String.fromCharCode(num(a[0]))),
    isspace: a => +/\s/.test(String.fromCharCode(num(a[0]))), isupper: a => +/[A-Z]/.test(String.fromCharCode(num(a[0]))), islower: a => +/[a-z]/.test(String.fromCharCode(num(a[0]))),
    atoi: a => parseInt(cstr(a[0]), 10) || 0, to_string: a => a[0] instanceof Fl ? gfmt(a[0].v, 6) : String(num(a[0])),
    rand: () => 4, srand: () => 0, time: () => 0, setprecision: a => ({ prec: num(a[0]) }), exit: () => { throw new Ctl('exit'); },
  };
  const isChar = (n, sc) => { if (n[0] === 'chr') return true; if (n[0] === 'cast') return n[1].k === 'char' && !n[1].ptr; if (n[0] === 'id' || n[0] === 'idx') { try { const c = cellOf(n, sc); return !!(c.ty && c.ty.k === 'char' && !c.ty.ptr); } catch (e) { return false; } } return false; };
  const cellOf = (n, sc) => {
    switch (n[0]) {
      case 'id': { const c = find(sc, n[1]); if (!c) throw new Err(`'${n[1]}' undeclared (first use in this function)`); return c; }
      case 'idx': {
        const b = ev(n[1], sc), i = num(ev(n[2], sc));
        if (Array.isArray(b)) { if (i < 0 || i >= b.length) throw new Err(`array index ${i} is out of bounds (size ${b.length})`); return { get v() { return b[i]; }, set v(x) { b[i] = coerce(b.ty, x); }, get ty() { return b.ty; } }; }
        if (typeof b === 'string') return { get v() { return b.charCodeAt(i) || 0; }, set v(x) { const bc = cellOf(n[1], sc), s = bc.v; bc.v = s.slice(0, i) + String.fromCharCode(num(x)) + s.slice(i + 1); }, ty: { k: 'char', ptr: 0 } };
        throw new Err('subscripted value is not an array');
      }
      case 'un': if (n[1] === '*') { const v = ev(n[2], sc); if (v && v.ref) return v.ref; if (Array.isArray(v)) return cellOf(['idx', n[2], ['num', 0, false]], sc); throw new Err('invalid pointer dereference'); } break;
    }
    throw new Err('lvalue required (cannot assign to this expression)');
  };
  const callFn = (f, args, sc) => {
    if (++depth > 700) throw new Err('Segmentation fault: stack overflow (infinite recursion?)');
    const s = new Sc(G);
    f.ps.forEach((pm, i) => { if (i >= args.length) { s.m.set(pm.name, { ty: pm.ty, v: 0 }); return; } if (pm.ref) s.m.set(pm.name, cellOf(args[i], sc)); else { const v = ev(args[i], sc); s.m.set(pm.name, { ty: pm.ty, v: pm.arr ? v : coerce(pm.ty, v) }); } });
    let r = 0; try { execBlock(f.body, s); } catch (e) { if (e instanceof Ctl && e.k === 'ret') r = e.v; else throw e; } finally { depth--; }
    return f.ty.k === 'void' ? 0 : coerce(f.ty, r);
  };
  const fill = (arr, init, sc) => {
    if (init[0] === 'str') { const s = init[1]; for (let i = 0; i < arr.length; i++) arr[i] = i < s.length ? s.charCodeAt(i) : 0; return; }
    init[1].forEach((it, i) => { if (i >= arr.length) throw new Err('excess elements in array initializer'); if (it[0] === 'list') fill(arr[i], it, sc); else arr[i] = coerce(arr.ty, ev(it, sc)); });
  };
  const ev = (n, sc) => {
    if (++steps > LIMIT) throw new Err('Time limit exceeded (possible infinite loop)');
    switch (n[0]) {
      case 'num': return n[2] ? new Fl(n[1]) : n[1];
      case 'chr': case 'str': return n[1];
      case 'id': { const c = find(sc, n[1]); if (c) return c.v; const k = KW[n[1]]; if (k !== undefined) return k; throw new Err(`'${n[1]}' undeclared (first use in this function)`); }
      case 'idx': return cellOf(n, sc).v;
      case 'call': {
        const nm = n[1], A = n[2];
        if (nm === 'swap') { const a = cellOf(A[0], sc), b = cellOf(A[1], sc), t = a.v; a.v = b.v; b.v = t; return 0; }
        if (nm === 'getline') { const c = cellOf(A[1], sc); if (inp.p >= inp.s.length) { failbit = 1; return CIN; } let e = inp.s.indexOf('\n', inp.p); if (e < 0) e = inp.s.length; c.v = inp.s.slice(inp.p, e).replace(/\r$/, ''); inp.p = e + 1; return CIN; }
        const f = prog.fns[nm]; if (f) return callFn(f, A, sc);
        const av = A.map(x => ev(x, sc)); if (BI[nm]) return BI[nm](av);
        throw new Err(`implicit declaration of function '${nm}' (not supported by the built-in engine)`);
      }
      case 'meth': {
        const o = ev(n[1], sc), m = n[2], a = n[3];
        if (m === 'length' || m === 'size') return typeof o === 'string' || Array.isArray(o) ? o.length : 0;
        if (m === 'empty') return +(o.length === 0);
        if (m === 'push_back') { o.push(coerce(o.ty, ev(a[0], sc))); return 0; }
        if (m === 'pop_back') { o.pop(); return 0; } if (m === 'back') return o[o.length - 1]; if (m === 'front') return o[0];
        if (m === 'clear') { if (Array.isArray(o)) o.length = 0; else cellOf(n[1], sc).v = ''; return 0; }
        if (m === 'at') return cellOf(['idx', n[1], a[0]], sc).v; if (m === 'c_str') return o;
        if (m === 'substr') return o.substr(num(ev(a[0], sc)), a[1] ? num(ev(a[1], sc)) : undefined);
        throw new Err(`unsupported method '${m}'`);
      }
      case 'un': {
        if (n[1] === '&') return { ref: cellOf(n[2], sc) };
        const v = ev(n[2], sc);
        if (n[1] === '*') { if (v && v.ref) return v.ref.v; if (Array.isArray(v)) return v[0]; throw new Err('invalid pointer dereference'); }
        if (n[1] === '!') return truth(v) ? 0 : 1;
        if (n[1] === '-') return v instanceof Fl ? new Fl(-v.v) : (-num(v)) | 0;
        if (n[1] === '~') return ~num(v); return v;
      }
      case 'pre': case 'post': { const c = cellOf(n[2], sc), old = c.v, nv = arith(n[1] === '++' ? '+' : '-', old, 1); c.v = coerce(c.ty, nv); return n[0] === 'pre' ? c.v : old; }
      case 'bin': {
        const op = n[1];
        if (op === '&&') return +(truth(ev(n[2], sc)) && truth(ev(n[3], sc)));
        if (op === '||') return +(truth(ev(n[2], sc)) || truth(ev(n[3], sc)));
        const a = ev(n[2], sc);
        if (a === COUT && op === '<<') { const ch = isChar(n[3], sc), v = ev(n[3], sc); if (v === ENDL) w('\n'); else if (v === FIXED) cs.fixed = true; else if (v && v.prec !== undefined) cs.prec = v.prec; else w(ch && isN(v) ? String.fromCharCode(num(v)) : sout(v)); return COUT; }
        if (a === CIN && op === '>>') { cinRead(cellOf(n[3], sc)); return CIN; }
        return arith(op, a, ev(n[3], sc));
      }
      case 'as': {
        const c = cellOf(n[2], sc); let v = ev(n[3], sc);
        if (n[1] !== '=') v = arith(n[1].slice(0, -1), c.v, v);
        else if (Array.isArray(v)) { const nv = v.slice(); nv.ty = v.ty; v = nv; }
        c.v = coerce(c.ty, v); return c.v;
      }
      case 'tern': return truth(ev(n[1], sc)) ? ev(n[2], sc) : ev(n[3], sc);
      case 'cast': { const v = ev(n[2], sc); return n[1].ptr ? v : coerce(n[1], v); }
    }
    throw new Err('unsupported expression');
  };
  const execBlock = (b, sc) => { const s = new Sc(sc); for (const st of b) exec(st, s); };
  const isC = (e, k) => e instanceof Ctl && e.k === k;
  const exec = (n, sc) => {
    if (++steps > LIMIT) throw new Err('Time limit exceeded (possible infinite loop)');
    switch (n[0]) {
      case 'block': return execBlock(n[1], sc);
      case 'expr': ev(n[1], sc); return;
      case 'decl': for (const d of n[2]) {
        const ty = n[1]; let v;
        if (d.dims.length) {
          const dims = d.dims.map(x => x ? num(ev(x, sc)) : null);
          if (d.init && d.init[0] === 'list' && dims[0] === null) dims[0] = d.init[1].length;
          if (d.init && d.init[0] === 'str' && dims[0] === null) dims[0] = d.init[1].length + 1;
          if (dims.some(x => x == null || x < 0 || x > 1e6)) throw new Err('array size missing or invalid');
          v = mk(dims, ty); if (d.init) fill(v, d.init, sc);
        } else if (d.init) {
          if (d.init[0] === 'ctor') {
            const a = d.init[1].map(x => ev(x, sc));
            if (ty.k === 'vector') { v = []; const cnt = a.length ? num(a[0]) : 0; for (let i = 0; i < cnt; i++) v.push(a.length > 1 ? a[1] : zero(vecTy(ty))); } else v = a.length ? coerce(ty, a[0]) : zero(ty);
          } else v = coerce(ty.k === 'auto' ? { k: 'auto' } : ty, ev(d.init, sc));
        } else v = zero(ty);
        if (ty.k === 'vector' && Array.isArray(v)) { if (d.init && d.init[0] !== 'ctor') v = v.slice(); v.ty = vecTy(ty); }
        sc.m.set(d.name, { ty, v });
      } return;
      case 'if': if (truth(ev(n[1], sc))) exec(n[2], sc); else if (n[3]) exec(n[3], sc); return;
      case 'while': while (truth(ev(n[1], sc))) { try { exec(n[2], sc); } catch (e) { if (isC(e, 'brk')) break; if (isC(e, 'cont')) continue; throw e; } } return;
      case 'do': do { try { exec(n[1], sc); } catch (e) { if (isC(e, 'brk')) break; if (!isC(e, 'cont')) throw e; } } while (truth(ev(n[2], sc))); return;
      case 'for': { const s = new Sc(sc); if (n[1]) exec(n[1], s); while (!n[2] || truth(ev(n[2], s))) { try { exec(n[4], s); } catch (e) { if (isC(e, 'brk')) break; if (!isC(e, 'cont')) throw e; } if (n[3]) ev(n[3], s); } return; }
      case 'rfor': { const coll = ev(n[3], sc), items = typeof coll === 'string' ? [...coll].map(c => c.charCodeAt(0)) : coll; for (const x of items) { const s = new Sc(sc); s.m.set(n[2], { ty: n[1].k === 'auto' ? coll.ty : n[1], v: n[1].k === 'auto' ? x : coerce(n[1], x) }); try { exec(n[4], s); } catch (e) { if (isC(e, 'brk')) break; if (!isC(e, 'cont')) throw e; } } return; }
      case 'sw': {
        const v = num(ev(n[1], sc)); let at = n[2].findIndex(c => c.v && num(ev(c.v, sc)) === v); if (at < 0) at = n[2].findIndex(c => !c.v);
        if (at < 0) return;
        try { const s = new Sc(sc); for (let i = at; i < n[2].length; i++) for (const st of n[2][i].b) exec(st, s); } catch (e) { if (!isC(e, 'brk')) throw e; } return;
      }
      case 'ret': throw new Ctl('ret', n[1] ? ev(n[1], sc) : 0);
      case 'brk': throw new Ctl('brk'); case 'cont': throw new Ctl('cont');
    }
  };
  const G = new Sc(null);
  try { for (const d of prog.globals) exec(d, G); callFn(prog.fns.main, [], G); }
  catch (e) {
    if (isC(e, 'exit')) { /* normal */ }
    else if (e instanceof Err) return { ok: false, stdout: out.join(''), stderr: 'Runtime error: ' + e.message };
    else if (e instanceof RangeError) return { ok: false, stdout: out.join(''), stderr: 'Runtime error: stack overflow (infinite recursion?)' };
    else throw e;
  }
  return { ok: true, stdout: out.join(''), stderr: '' };
}
module.exports = { run };
