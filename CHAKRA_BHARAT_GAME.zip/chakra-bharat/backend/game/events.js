/**
 * CHAKRA-BHARAT: Event Manager & Consequence Engine
 * The central innovation:
 * BUILD → SCAN → SYSTEM REMEMBERS → WORLD CHANGES → ADAPT → REBUILD
 *
 * ConsequenceEngine evaluates:
 * EVENT + PLAYER INFRASTRUCTURE + PLAYER RESOURCES + GAME STATE = FINAL CONSEQUENCE
 */

const path = require('path');
const ResourceManager = require('./resources');

class ConsequenceEngine {
  /**
   * Evaluates the outcome of an event on a specific player based on their built infrastructure.
   */
  static evaluate(event, player, gameState = {}) {
    const consequences = {
      playerId: player.id,
      playerName: player.name,
      civilizationName: player.civilizationName,
      eventId: event.id,
      eventTitle: event.title,
      category: event.category,
      hasInfrastructure: false,
      infrastructureName: null,
      deltas: { food: 0, water: 0, materials: 0, wealth: 0, culture: 0 },
      narrative: '',
      heroExplanation: '',
      mitigationDelta: 0
    };

    const buildings = player.buildings || {};

    switch (event.id) {
      case 'DROUGHT': {
        player.stats.droughtsSurvived = (player.stats.droughtsSurvived || 0) + 1;
        player.stats.negativeEventsSurvived = (player.stats.negativeEventsSurvived || 0) + 1;

        if (buildings.WATER_SYSTEM) {
          consequences.hasInfrastructure = true;
          consequences.infrastructureName = 'Water System (जल संरक्षण)';
          consequences.deltas.water = -1;
          consequences.mitigationDelta = 2; // saved 2 water
          consequences.narrative = 'Your Water System stepwells & reservoirs preserved emergency reserves! Loss reduced to -1 Water.';
          consequences.heroExplanation = 'PROTECTED: Your previous physical placement of the WATER SYSTEM shielded your people from severe dehydration (3 Water → 1 Water).';
          player.stats.timesProtectedByWaterSystem = (player.stats.timesProtectedByWaterSystem || 0) + 1;
        } else {
          consequences.hasInfrastructure = false;
          player.stats.unprotectedCrises = (player.stats.unprotectedCrises || 0) + 1;
          consequences.deltas.water = -3;
          consequences.mitigationDelta = 0;
          consequences.narrative = 'Lacking traditional water storage, open reservoirs evaporated: -3 Water!';
          consequences.heroExplanation = 'UNPROTECTED: Without a Water System, extreme summer heat depleted stored water supplies.';
        }
        break;
      }

      case 'FLOOD': {
        player.stats.floodsSurvived = (player.stats.floodsSurvived || 0) + 1;
        player.stats.negativeEventsSurvived = (player.stats.negativeEventsSurvived || 0) + 1;

        if (buildings.WATER_SYSTEM) {
          consequences.hasInfrastructure = true;
          consequences.infrastructureName = 'Water System (जल संरक्षण)';
          consequences.deltas.materials = -1;
          consequences.mitigationDelta = 2; // saved 1 material and 1 food
          consequences.narrative = 'Stepwell channels and overflow dikes diverted flood runoff! Minimal damage: -1 Material.';
          consequences.heroExplanation = 'PROTECTED: Dual-purpose retention channels prevented catastrophic erosion of grain stores.';
        } else {
          consequences.hasInfrastructure = false;
          player.stats.unprotectedCrises = (player.stats.unprotectedCrises || 0) + 1;
          consequences.deltas.materials = -2;
          consequences.deltas.food = -1;
          consequences.mitigationDelta = 0;
          consequences.narrative = 'Unchecked river surge breached storage yards: -2 Materials, -1 Food!';
          consequences.heroExplanation = 'UNPROTECTED: Lacking drainage channels, river surge swept through unguarded storehouses.';
        }
        break;
      }

      case 'TRADE_BOOM': {
        if (buildings.MARKET) {
          consequences.hasInfrastructure = true;
          consequences.infrastructureName = 'Market (व्यापार मंडी)';
          consequences.deltas.wealth = 4;
          consequences.mitigationDelta = 2; // +2 extra wealth
          consequences.narrative = 'Your bustling MARKET captured supreme transit tariffs and guild trading: +4 Wealth!';
          consequences.heroExplanation = 'AMPLIFIED: The physical Market guild network enabled your merchants to double commerce profits.';
          player.stats.timesBenefitedByMarket = (player.stats.timesBenefitedByMarket || 0) + 1;
        } else {
          consequences.hasInfrastructure = false;
          consequences.deltas.wealth = 2;
          consequences.narrative = 'Caravans passed through your boundaries: +2 Wealth.';
          consequences.heroExplanation = 'STANDARD: Wayside commerce yielded base tolls, but without a Market, maximum profits were missed.';
        }
        break;
      }

      case 'GOOD_MONSOON': {
        consequences.deltas.food = 2;
        consequences.deltas.water = 2;

        if (buildings.FARM) {
          consequences.hasInfrastructure = true;
          consequences.infrastructureName = 'Farm (कृषि क्षेत्र)';
          consequences.deltas.food += 1; // +3 food total
          consequences.narrative = 'Bountiful rains irrigated your cultivated FARMLANDS: +3 Food, +2 Water!';
          consequences.heroExplanation = 'SYNERGY: Systematic agricultural land preparation maximized monsoon irrigation.';
        } else {
          consequences.narrative = 'Nourishing monsoon rains swept across your territory: +2 Food, +2 Water.';
          consequences.heroExplanation = 'NATURAL BOUNTY: Seasonal rains replenished local riverbeds and wild crops.';
        }
        break;
      }

      case 'RESOURCE_SHORTAGE': {
        player.stats.negativeEventsSurvived = (player.stats.negativeEventsSurvived || 0) + 1;

        if (buildings.FORT) {
          consequences.hasInfrastructure = true;
          consequences.infrastructureName = 'Fort (दुर्ग)';
          consequences.deltas.materials = -1;
          consequences.mitigationDelta = 1;
          consequences.narrative = 'Fortified depot stockpiles buffered the shortage: minimal loss of -1 Material.';
          consequences.heroExplanation = 'PROTECTED: Citadel warehouses preserved stone and timber reserves during supply disruption.';
        } else {
          consequences.hasInfrastructure = false;
          player.stats.unprotectedCrises = (player.stats.unprotectedCrises || 0) + 1;
          consequences.deltas.materials = -2;
          consequences.narrative = 'Logistical bottlenecks and quarry strains depleted reserves: -2 Materials!';
          consequences.heroExplanation = 'UNPROTECTED: Open storage yards suffered spoilage and logistical halts.';
        }
        break;
      }

      case 'FESTIVAL': {
        player.stats.festivalsCelebrated = (player.stats.festivalsCelebrated || 0) + 1;
        consequences.deltas.food = 1;
        consequences.deltas.wealth = 1;
        consequences.deltas.culture = 5;
        consequences.narrative = 'Joyous festival of lights and devotion! Citizens rejoice: +5 Culture Score, +1 Food, +1 Wealth!';
        consequences.heroExplanation = 'HARMONY: Collective celebration reinforced communal solidarity and trade enthusiasm.';
        break;
      }

      default: {
        consequences.narrative = 'The event concluded quietly.';
        break;
      }
    }

    // Apply resource deltas with non-negative guarantee
    for (const [res, delta] of Object.entries(consequences.deltas)) {
      if (res === 'culture') {
        player.scoreBreakdown.culturalDevelopment = (player.scoreBreakdown.culturalDevelopment || 0) + delta;
      } else if (ResourceManager.CORE_RESOURCES.includes(res)) {
        if (delta > 0) {
          player.resources[res] = (player.resources[res] || 0) + delta;
        } else if (delta < 0) {
          // Deduct safely down to 0
          player.resources[res] = Math.max(0, (player.resources[res] || 0) + delta);
        }
      }
    }

    return consequences;
  }
}

class EventManager {
  constructor(eventsData) {
    if (eventsData) {
      this.events = eventsData.events;
    } else {
      const data = require(path.join(__dirname, '../../data/events.json'));
      this.events = data.events;
    }

    this.eventMap = new Map();
    this.events.forEach(e => this.eventMap.set(e.id, e));
    this.recentEvents = [];
  }

  getEvent(eventId) {
    if (!eventId) return null;
    return this.eventMap.get(eventId.toUpperCase()) || null;
  }

  getAllEvents() {
    return this.events;
  }

  /**
   * Select a random event, avoiding immediate repetition
   */
  drawRandomEvent() {
    const available = this.events.filter(e => !this.recentEvents.slice(-2).includes(e.id));
    const pool = available.length > 0 ? available : this.events;
    const randomIndex = Math.floor(Math.random() * pool.length);
    const chosen = pool[randomIndex];

    this.recentEvents.push(chosen.id);
    if (this.recentEvents.length > 5) {
      this.recentEvents.shift();
    }

    return chosen;
  }

  /**
   * Process an event across all active players through the ConsequenceEngine
   */
  triggerEvent(eventIdOrEvent, players, gameState = {}) {
    const event = typeof eventIdOrEvent === 'string' ? this.getEvent(eventIdOrEvent) : eventIdOrEvent;
    if (!event) {
      throw new Error(`Unknown event: ${eventIdOrEvent}`);
    }

    const playerResults = players.map(player => {
      return ConsequenceEngine.evaluate(event, player, gameState);
    });

    return {
      event,
      timestamp: new Date().toISOString(),
      playerResults
    };
  }
}

module.exports = {
  EventManager,
  ConsequenceEngine
};
