/**
 * CHAKRA-BHARAT: Player Model
 * Represents an individual civilization managed by a physical or digital player.
 */

const ResourceManager = require('./resources');

class Player {
  constructor({ id, name, civilizationName, startingResources, badge }) {
    this.id = id || 1;
    this.name = name || `Player ${this.id}`;
    this.civilizationName = civilizationName || `Civilization ${this.id}`;
    this.badge = badge || this.getDefaultBadge(this.id);

    this.resources = ResourceManager.createInitialResources(startingResources);

    this.buildings = {
      FARM: false,
      WATER_SYSTEM: false,
      MARKET: false,
      FORT: false
    };

    this.buildingHistory = [];

    // Authoritative 4-partition strategy-board state.
    // Each player owns a 2x3 quadrant on the merged Chakra-Bharat board.
    this.board = {
      rows: 2,
      cols: 3,
      placements: []
    };

    this.stats = {
      buildingsBuilt: 0,
      tradesCompleted: 0,
      droughtsSurvived: 0,
      floodsSurvived: 0,
      festivalsCelebrated: 0,
      totalResourcesCollected: 0,
      timesProtectedByWaterSystem: 0,
      timesBenefitedByMarket: 0,
      negativeEventsSurvived: 0,
      failedActions: 0,
      failedBuilds: 0,
      failedTrades: 0,
      turnsEnded: 0,
      collections: 0,
      specialActions: 0,
      unprotectedCrises: 0
    };

    this.score = 0;
    this.scoreBreakdown = {
      development: 0,
      resourceEfficiency: 0,
      culturalDevelopment: 0,
      sustainability: 0,
      adaptability: 0,
      trade: 0,
      total: 0
    };

    this.achievements = [];
  }

  getDefaultBadge(id) {
    const badges = [
      { color: '#D4AF37', emblem: 'wheel', symbol: '☸', title: 'Dharma Chakra' },
      { color: '#3182CE', emblem: 'lotus', symbol: '🪷', title: 'Nilotpala Lotus' },
      { color: '#38A169', emblem: 'banyan', symbol: '🌳', title: 'Kalpavriksha' },
      { color: '#DD6B20', emblem: 'sun', symbol: '☀️', title: 'Surya Tejas' }
    ];
    return badges[(id - 1) % badges.length];
  }

  checkAchievements() {
    const earned = [];

    // BUILDER: Construct all 4 core buildings
    if (this.buildings.FARM && this.buildings.WATER_SYSTEM && this.buildings.MARKET && this.buildings.FORT) {
      if (!this.hasAchievement('BUILDER')) {
        earned.push({
          id: 'BUILDER',
          title: 'Master Architect (वास्तुशिल्पी)',
          desc: 'Constructed all four core civilization pillars: Farm, Water System, Market, and Fort.'
        });
      }
    }

    // WATER KEEPER: Built Water System and survived a Drought
    if (this.buildings.WATER_SYSTEM && this.stats.timesProtectedByWaterSystem >= 1) {
      if (!this.hasAchievement('WATER_KEEPER')) {
        earned.push({
          id: 'WATER_KEEPER',
          title: 'Water Guardian (जल रक्षक)',
          desc: 'Preserved your civilization with an active Water System during a severe Drought.'
        });
      }
    }

    // MASTER TRADER: Completed 3 successful trades
    if (this.stats.tradesCompleted >= 3) {
      if (!this.hasAchievement('MASTER_TRADER')) {
        earned.push({
          id: 'MASTER_TRADER',
          title: 'Sarthavaha / Merchant Guild Leader (सार्थवाह)',
          desc: 'Completed 3 successful trade exchanges across civilizations.'
        });
      }
    }

    // RESILIENT CIVILIZATION: Survived 3 negative events
    if (this.stats.negativeEventsSurvived >= 3) {
      if (!this.hasAchievement('RESILIENT_CIVILIZATION')) {
        earned.push({
          id: 'RESILIENT_CIVILIZATION',
          title: 'Unshakable Realm (अजेय राष्ट्र)',
          desc: 'Overcame 3 severe natural crises and emerged prosperous.'
        });
      }
    }

    // CULTURAL HEART: Celebrated festivals and high cultural score
    if (this.stats.festivalsCelebrated >= 2 || (this.scoreBreakdown && this.scoreBreakdown.culturalDevelopment >= 10)) {
      if (!this.hasAchievement('CULTURAL_HEART')) {
        earned.push({
          id: 'CULTURAL_HEART',
          title: 'Beacon of Heritage (संस्कृति दीप)',
          desc: 'United the people through sacred festivals and cultural enlightenment.'
        });
      }
    }

    for (const ach of earned) {
      this.achievements.push(ach);
    }

    return earned;
  }

  hasAchievement(id) {
    return this.achievements.some(a => a.id === id);
  }

  toJSON() {
    return {
      id: this.id,
      name: this.name,
      civilizationName: this.civilizationName,
      badge: this.badge,
      resources: { ...this.resources },
      buildings: { ...this.buildings },
      buildingHistory: [...this.buildingHistory],
      board: {
        rows: this.board.rows,
        cols: this.board.cols,
        placements: this.board.placements.map(p => ({ ...p }))
      },
      stats: { ...this.stats },
      score: this.score,
      scoreBreakdown: { ...this.scoreBreakdown },
      achievements: [...this.achievements]
    };
  }
}

module.exports = Player;
