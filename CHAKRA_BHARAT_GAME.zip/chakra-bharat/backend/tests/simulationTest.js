/**
 * CHAKRA-BHARAT: Automated Test & Simulation Suite
 * Verifies:
 * 1. Resource bounds and deductions
 * 2. Building construction rules & costs
 * 3. Consequence Engine logic across all 6 MVP events
 * 4. Drought consequence mitigation (Water System: -1 vs -3)
 * 5. Scoring algorithm (100-point total across 6 categories)
 * 6. Turn rotation and game conclusion
 * 7. Hardware serial parser and command pipeline
 * 8. Quick Demo Walkthrough 4-step sequence
 */

const assert = require('assert');
const GameEngine = require('../game/gameEngine');
const HardwareManager = require('../hardware/serial');
const ResourceManager = require('../game/resources');
const BuildingManager = require('../game/buildings');
const { EventManager, ConsequenceEngine } = require('../game/events');
const ScoringManager = require('../game/scoring');

console.log('====================================================');
console.log('  RUNNING CHAKRA-BHARAT AUTOMATED VERIFICATION SUITE');
console.log('====================================================');

let passedTests = 0;
function test(name, fn) {
  try {
    fn();
    console.log(`  ✓ PASS: ${name}`);
    passedTests++;
  } catch (err) {
    console.error(`  ✕ FAIL: ${name}`);
    console.error(`    ${err.message}`);
    process.exit(1);
  }
}

// 1. RESOURCE MANAGER TESTS
test('ResourceManager prevents negative resources and deducts correctly', () => {
  const current = { food: 5, water: 5, materials: 5, wealth: 5 };
  const cost = { materials: 2, water: 1 };

  assert.strictEqual(ResourceManager.hasEnough(current, cost), true);
  const result = ResourceManager.deduct(current, cost);
  assert.strictEqual(result.success, true);
  assert.strictEqual(current.materials, 3);
  assert.strictEqual(current.water, 4);

  // Attempt overdraw
  const excessiveCost = { materials: 10 };
  assert.strictEqual(ResourceManager.hasEnough(current, excessiveCost), false);
  const overdrawResult = ResourceManager.deduct(current, excessiveCost);
  assert.strictEqual(overdrawResult.success, false);
  assert.strictEqual(current.materials, 3); // Unchanged
});

// 2. BUILDING MANAGER TESTS
test('BuildingManager validates costs and builds core structures', () => {
  const bm = new BuildingManager();
  const mockPlayer = {
    id: 1,
    name: 'Arjun',
    resources: { food: 5, water: 5, materials: 5, wealth: 5 },
    buildings: { FARM: false, WATER_SYSTEM: false, MARKET: false, FORT: false },
    stats: { buildingsBuilt: 0 }
  };

  // Build Farm (cost: 2 materials, 1 water)
  const buildResult = bm.build(mockPlayer, 'FARM', 1);
  assert.strictEqual(buildResult.success, true);
  assert.strictEqual(mockPlayer.buildings.FARM, true);
  assert.strictEqual(mockPlayer.resources.materials, 3);
  assert.strictEqual(mockPlayer.resources.water, 4);

  // Duplicate build rejected
  const dupResult = bm.build(mockPlayer, 'FARM', 1);
  assert.strictEqual(dupResult.success, false);
});

// 3. CONSEQUENCE ENGINE: HERO DROUGHT TEST (KEY INNOVATION)
test('ConsequenceEngine mitigates Drought water loss (3 -> 1) with Water System', () => {
  const em = new EventManager();
  const droughtEvent = em.getEvent('DROUGHT');
  assert(droughtEvent !== null, 'Drought event must exist');

  // Player A: Has Water System
  const playerA = {
    id: 1,
    name: 'Indus Builders',
    resources: { food: 5, water: 5, materials: 5, wealth: 5 },
    buildings: { WATER_SYSTEM: true },
    stats: {},
    scoreBreakdown: {}
  };

  // Player B: Lacks Water System
  const playerB = {
    id: 2,
    name: 'Vedic Pioneers',
    resources: { food: 5, water: 5, materials: 5, wealth: 5 },
    buildings: { WATER_SYSTEM: false },
    stats: {},
    scoreBreakdown: {}
  };

  const outcomeA = ConsequenceEngine.evaluate(droughtEvent, playerA);
  const outcomeB = ConsequenceEngine.evaluate(droughtEvent, playerB);

  // Assert consequences
  assert.strictEqual(outcomeA.deltas.water, -1, 'Player with Water System must lose only 1 Water');
  assert.strictEqual(outcomeB.deltas.water, -3, 'Player without Water System must lose 3 Water');
  assert.strictEqual(playerA.resources.water, 4, 'Player A water should be 4');
  assert.strictEqual(playerB.resources.water, 2, 'Player B water should be 2');
  assert.strictEqual(outcomeA.hasInfrastructure, true);
  assert.strictEqual(outcomeB.hasInfrastructure, false);
});

// 4. CONSEQUENCE ENGINE: TRADE BOOM WITH MARKET
test('ConsequenceEngine amplifies Trade Boom wealth (+4 vs +2) with Market', () => {
  const em = new EventManager();
  const tradeEvent = em.getEvent('TRADE_BOOM');

  const playerWithMarket = {
    id: 1,
    resources: { food: 5, water: 5, materials: 5, wealth: 5 },
    buildings: { MARKET: true },
    stats: {},
    scoreBreakdown: {}
  };

  const playerNoMarket = {
    id: 2,
    resources: { food: 5, water: 5, materials: 5, wealth: 5 },
    buildings: { MARKET: false },
    stats: {},
    scoreBreakdown: {}
  };

  const resMarket = ConsequenceEngine.evaluate(tradeEvent, playerWithMarket);
  const resNoMarket = ConsequenceEngine.evaluate(tradeEvent, playerNoMarket);

  assert.strictEqual(resMarket.deltas.wealth, 4, 'Market should grant +4 Wealth');
  assert.strictEqual(resNoMarket.deltas.wealth, 2, 'No Market should grant +2 Wealth');
  assert.strictEqual(playerWithMarket.resources.wealth, 9);
  assert.strictEqual(playerNoMarket.resources.wealth, 7);
});

// 5. SCORING MANAGER TESTS (100 PTS MAXIMUM)
test('ScoringManager correctly calculates 100-point score across 6 categories', () => {
  const masterPlayer = {
    id: 1,
    name: 'Emperor Ashoka',
    resources: { food: 10, water: 8, materials: 8, wealth: 10 },
    buildings: { FARM: true, WATER_SYSTEM: true, MARKET: true, FORT: true },
    stats: {
      buildingsBuilt: 4,
      tradesCompleted: 3,
      timesProtectedByWaterSystem: 2,
      timesBenefitedByMarket: 2,
      negativeEventsSurvived: 3,
      festivalsCelebrated: 2
    },
    scoreBreakdown: { culturalDevelopment: 5 }
  };

  const breakdown = ScoringManager.calculatePlayerScore(masterPlayer);

  assert.strictEqual(breakdown.development, 25, 'Development should be 25/25 for all 4 buildings');
  assert.strictEqual(breakdown.resourceEfficiency, 20, 'Efficiency should be max 20');
  assert.strictEqual(breakdown.sustainability, 15, 'Sustainability should be 15/15');
  assert.strictEqual(breakdown.adaptability, 15, 'Adaptability should be 15/15');
  assert.strictEqual(breakdown.trade, 10, 'Trade should be 10/10');
  assert.strictEqual(breakdown.total, 100, 'Total score should equal exactly 100');
});

// 6. HARDWARE PROTOCOL & VIRTUAL CONTROLLER
test('HardwareManager correctly parses serial packets and drives Virtual Mode', () => {
  const rawCommand = 'PLAYER=2;ACTION=BUILD;ITEM=WATER_SYSTEM\n';
  const parsed = HardwareManager.parseMessage(rawCommand);

  assert.deepStrictEqual(parsed, {
    player: 2,
    action: 'BUILD',
    item: 'WATER_SYSTEM'
  });

  const rawButton = 'PLAYER=1;ACTION=BUTTON;ITEM=NEXT\n';
  const parsedButton = HardwareManager.parseMessage(rawButton);
  assert.deepStrictEqual(parsedButton, {
    player: 1,
    action: 'BUTTON',
    item: 'NEXT'
  });
});

// 7. FULL GAME ENGINE SIMULATION (8 ROUNDS TO GAME OVER)
test('GameEngine completes full multi-round game and evaluates victory', () => {
  const engine = new GameEngine();
  engine.createGame({
    mode: 'basic',
    players: [
      { id: 1, name: 'Arjun', civilizationName: 'Indus Realm' },
      { id: 2, name: 'Vikram', civilizationName: 'Vedic Realm' }
    ]
  });

  assert.strictEqual(engine.status, 'ACTIVE');
  assert.strictEqual(engine.turnManager.currentRound, 1);

  // Player 1 builds Farm
  const b1 = engine.executeAction(1, 'BUILD', { buildingId: 'FARM' });
  assert.strictEqual(b1.success, true);

  // Player 1 ends turn -> Player 2's turn
  engine.executeAction(1, 'END_TURN');
  assert.strictEqual(engine.getActivePlayer().id, 2);

  // Player 2 collects yield
  const c2 = engine.executeAction(2, 'COLLECT');
  assert.strictEqual(c2.success, true);

  // Player 2 ends turn -> Round complete, event triggers
  const r1End = engine.executeAction(2, 'END_TURN');
  assert.strictEqual(r1End.success, true);
  assert(engine.currentEvent !== null, 'An event should trigger at the end of the round');

  // Dismiss event
  engine.dismissCurrentEvent();
  assert.strictEqual(engine.status, 'ACTIVE');
});

// 8. QUICK DEMO 4-STEP WALKTHROUGH
test('Quick Demo Walkthrough completes steps 1 through 4 successfully', () => {
  const engine = new GameEngine();

  const step1 = engine.runDemoStep(1);
  assert.strictEqual(step1.success, true);
  assert.strictEqual(step1.step, 1);

  const step2 = engine.runDemoStep(2);
  assert.strictEqual(step2.success, true);
  assert.strictEqual(engine.getPlayer(1).buildings.WATER_SYSTEM, true);

  const step3 = engine.runDemoStep(3);
  assert.strictEqual(step3.success, true);
  assert.strictEqual(engine.currentEvent.id, 'DROUGHT');

  const step4 = engine.runDemoStep(4);
  assert.strictEqual(step4.success, true);
  assert(step4.heroExplanation !== null);
  assert(step4.heroExplanation.p1Outcome.includes('-1 Water'));
  assert(step4.heroExplanation.p2Outcome.includes('-3 Water'));
});

console.log('====================================================');
console.log(`  ALL ${passedTests} TESTS PASSED SUCCESSFULLY!`);
console.log('====================================================');
