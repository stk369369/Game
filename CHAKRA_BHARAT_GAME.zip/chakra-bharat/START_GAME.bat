@echo off
setlocal
cd /d "%~dp0backend"
if not exist node_modules (
  echo Installing game dependencies...
  call npm install
  if errorlevel 1 exit /b 1
)
echo.
echo Starting CHAKRA-BHARAT...
echo Open http://localhost:3000
echo.
call npm start
