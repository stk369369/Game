# CHAKRA-BHARAT (चक्र-भारत)

### Smart Indian Civilization Strategy Game — Physical Tabletop + Digital Strategy Engine
**Indian Civilization Learning Game**  
*Problem Statement: “Conceptualize and develop unique toys and games based on Indian civilization, history and culture.”*

---

## 1. Executive Summary & Core Innovation

**CHAKRA-BHARAT** is not an ordinary board game, quiz app, or decorative Indian website. It is a **smart hybrid civilization strategy game** where physical actions on a tabletop game board dynamically shape and dictate consequences in an authoritative digital strategy engine.

### The Central Innovation Loop:
```
BUILD (Tabletop)
  ↓
SCAN (RFID / ESP32)
  ↓
SYSTEM REMEMBERS (Authoritative Game Engine)
  ↓
WORLD CHANGES (Dynamic Historical Events)
  ↓
CONSEQUENCE MITIGATION (Cause & Effect)
  ↓
ADAPT & REBUILD
```

### Hero Example:
1. A player physically constructs and scans a **Water System** (representing ancient Indian stepwells/baolis).
2. The digital game state registers `waterSystem = true`.
3. Later in the game, an environmental crisis occurs: **DROUGHT**.
4. **Player WITH Water System**: Suffers only **-1 Water** (mitigated).
5. **Player WITHOUT Water System**: Suffers full disaster penalty of **-3 Water**.
6. The system presents a clear explanation: *"Your previous physical decision modified your future survival."*

---

## 2. Project Architecture

```
c:/civilization game/
├── frontend/
│   ├── index.html            # Primary single-page shell, navigation, modals, toasts
│   ├── style.css             # Indian civilization aesthetic, animations, responsive layout
│   ├── app.js                # Frontend orchestrator, WebSocket/REST client, audio & board mirror
│   │
│   ├── pages/
│   │   ├── start.html        # Game setup, 2-4 civilizations, mode selector, demo launcher
│   │   ├── game.html         # Civilization command dashboard, 4-building physical board mirror
│   │   └── result.html       # Champion crowning, animated 100-pt category breakdown, leaderboard
│   │
│   └── assets/
│       ├── icons/            # SVG vector icons (Food, Water, Materials, Wealth, Chakra)
│       ├── buildings/        # SVG illustrations (Farm, Water System, Market, Fort)
│       └── sounds/           # Web Audio API procedural synthesizer (zero audio file dependencies)
│
├── backend/
│   ├── server.js             # Express HTTP + WebSocket server & static asset host
│   │
│   ├── game/
│   │   ├── gameEngine.js     # Authoritative Game Engine & Single Source of Truth
│   │   ├── player.js         # Civilization player models, achievements, and stats
│   │   ├── resources.js      # Resource manager (non-negative validation, yields)
│   │   ├── buildings.js      # Building construction logic and RFID UID mappings
│   │   ├── events.js         # Event catalog and dedicated Consequence Engine
│   │   ├── scoring.js        # 100-point scoring algorithm across 6 weighted categories
│   │   ├── turns.js          # Turn progression, round limits, and phase transitions
│   │   └── trade.js          # Player diplomacy and Caravan Guild barter
│   │
│   └── hardware/
│       └── serial.js         # ESP32 serial communication bridge + Virtual Hardware Mode
│
├── data/
│   ├── buildings.json        # 4 Core building definitions, costs, and concepts
│   ├── events.json           # 6 MVP historical events and consequence rules
│   └── gameModes.json        # Basic Mode (8 rounds), Advanced Mode (10 rounds), Demo Mode
│
└── README.md                 # Complete documentation, hardware protocol & setup manual
```

---

## 3. Four Core Resources

| Resource | Concept | Purpose in Gameplay |
| :--- | :--- | :--- |
| 🌾 **FOOD** | Agricultural grain & crops | Population sustenance, growth, and religious rituals |
| 💧 **WATER** | River channels, baolis & wells | Survival buffer, drought mitigation, and sustainability score |
| 🪨 **MATERIALS** | Cut sandstone & timber | Physical construction of civilization infrastructure |
| 🪙 **WEALTH** | Ancient punch-marked coins / Mohurs | Trade negotiations, market expansion, and economic power |

*Starting stockpile*: 5 Food, 5 Water, 5 Materials, 5 Wealth (Basic Mode).  
*Non-negative guarantee*: Resources cannot drop below 0.

---

## 4. Four Pillars of Civilization (Buildings)

| Building | Cost | Indian Civilization Concept | Gameplay Perk & Consequence |
| :--- | :--- | :--- | :--- |
| **FARM** | 🪨 2 Materials<br>💧 1 Water | *Monsoon-fed River Basin Agriculture* | **+2 Food** production yield each turn |
| **WATER SYSTEM** | 🪨 2 Materials<br>🪙 1 Wealth | *Stepwells (Baolis/Johads) & Reservoirs* | **Drought Mitigation**: Loss reduced from **-3 to -1 Water**; buffers against flood runoff |
| **MARKET** | 🪨 2 Materials<br>🪙 2 Wealth | *Historic Guild Networks (Shrenis)* | **Trade Boom Bounty**: Doubles Wealth gained during Trade Boom (**+4 vs +2**) |
| **FORT** | 🪨 3 Materials<br>🌾 1 Food | *Hill Forts (Durga) & Granary Citadels* | **Citadel Protection**: Buffers supply chains against material shortages and conflicts |

---

## 5. Dynamic Historical Events (The 6 MVP Events)

1. **GOOD MONSOON (शुभ वर्षा)** — *Positive*  
   Bountiful seasonal rains. All civilizations gain **+2 Food, +2 Water** (+3 Food if Farm is built).
2. **SEVERE DROUGHT (भीषण सूखा)** — *Disaster*  
   Summer monsoon fails.  
   • Without Water System: **-3 Water** (severe dehydration).  
   • With Water System: **-1 Water** (traditional stepwells preserve life).
3. **RIVER FLOOD (महा जलप्लावन)** — *Disaster*  
   River overflows banks.  
   • Without Water System: **-2 Materials, -1 Food**.  
   • With Water System: **-1 Material** (diversion channels protect granaries).
4. **TRADE BOOM (व्यापार उत्कर्ष)** — *Economic*  
   Caravans traverse trans-subcontinental routes.  
   • Without Market: **+2 Wealth**.  
   • With Market: **+4 Wealth** (customs and guild tariffs).
5. **RESOURCE SHORTAGE (संसाधन संकट)** — *Challenge*  
   Quarries and timber routes face rough terrain bottlenecks.  
   • Without Fort: **-2 Materials**.  
   • With Fort: **-1 Material** (fortified warehouses mitigate loss).
6. **GRAND HARVEST FESTIVAL (महोत्सव)** — *Cultural*  
   Citizens unite in celebration. Grants **+5 Culture Points, +1 Food, +1 Wealth**.

---

## 6. The Consequence Engine

The Consequence Engine in `backend/game/events.js` evaluates:
$$\text{EVENT} + \text{PLAYER INFRASTRUCTURE} + \text{PLAYER RESOURCES} + \text{GAME STATE} \Longrightarrow \text{FINAL CONSEQUENCE}$$

The backend Game Engine remains the **Single Source of Truth**. The hardware and frontend never invent or manipulate numerical rules independently.

---

## 7. 100-Point Authoritative Scoring System

| Category | Max Points | Evaluation Basis |
| :--- | :---: | :--- |
| **Development** | **25** | 5 pts per core building built + 5 pts bonus for completing all 4 |
| **Resource Efficiency** | **20** | +6 pts for zero depleted resources (no 0s) + balanced stockpile volume |
| **Cultural Development** | **15** | Festival participation points and sacred community rituals |
| **Sustainability** | **15** | +10 pts for Water System + healthy water reserves (water ≥ 3) |
| **Adaptability** | **15** | Successfully mitigating Droughts, Floods, and shortages |
| **Trade & Guilds** | **10** | +5 pts for Market + completed trades and Trade Boom bonuses |
| **TOTAL** | **100** | Final score determining the winning civilization |

---

## 8. Hardware Integration & Serial Protocol

### Hardware Architecture:
```
ESP32 Microcontroller
  ├── RC522 RFID Reader (SPI: SS=5, SCK=18, MOSI=23, MISO=19, RST=14)
  ├── 0.96" I2C OLED Display (SSD1306: SDA=21, SCL=22)
  ├── Push Buttons (CONFIRM=GPIO25, NEXT=GPIO26, EVENT=GPIO27)
  ├── Status LEDs (SUCCESS=GPIO16, ERROR=GPIO17, WS2812B=GPIO4)
  └── Buzzer (GPIO33)
```

### Serial Communication Protocol (115200 Baud):

**Hardware → Software (Commands):**
```text
PLAYER=1;ACTION=BUILD;ITEM=WATER_SYSTEM\n
PLAYER=2;ACTION=BUILD;ITEM=FARM\n
PLAYER=1;ACTION=BUTTON;ITEM=CONFIRM\n
PLAYER=1;ACTION=BUTTON;ITEM=NEXT\n
PLAYER=1;ACTION=BUTTON;ITEM=EVENT\n
```

**Software → Hardware (Telemetry / Feedback):**
```text
STATUS=SUCCESS;ITEM=WATER_SYSTEM;OLED=WATER BUILT\n
STATUS=ERROR;MESSAGE=INSUFFICIENT_RESOURCES;OLED=ERR: NEED MAT\n
EVENT=DROUGHT\n
TURN=PLAYER2\n
```

### Virtual Hardware Mode:
The game includes a **Virtual Hardware Controller Tray** directly in the UI. It executes the **exact same parser, protocol, and Game Engine logic** as physical hardware. When an ESP32 is plugged into USB, the system seamlessly detects the COM port and switches to Live Serial mode without restarting the game.

---

## 9. Quick Demo Walkthrough (30-Second Walkthrough)

To demonstrate the innovation to new players in under 1 minute:
1. Click the blue **★ QUICK DEMO (CAUSE & EFFECT)** button on the home screen.
2. **Step 1**: Initialize demo with two civilizations (Player 1: Indus Builders, Player 2: Vedic Pioneers).
3. **Step 2**: Player 1 scans/builds the **Water System**. Notice the system registers traditional stepwells.
4. **Step 3**: Trigger the **Drought Crisis**.
5. **Step 4**: The Consequence Engine reveals:
   - **Player 1 (Indus Builders)**: Suffered only **-1 Water**!
   - **Player 2 (Vedic Pioneers)**: Suffered full **-3 Water** penalty!
   - The hero callout displays: *"Your previous physical decision modified your future survival."*

---

## 10. Installation & Quick Start

### Prerequisites:
- Node.js v18+ installed

### Running the Server:
```bash
# Navigate to backend directory
cd "c:/civilization game/backend"

# Start the application
npm start
```

Open your browser and navigate to:
```
http://localhost:3000
```

---

## 11. ESP32 Arduino Firmware Sample (`.ino`)

Below is the minimal sketch to flash to an ESP32 board:

```cpp
#include <SPI.h>
#include <MFRC522.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SS_PIN 5
#define RST_PIN 14
#define BTN_CONFIRM 25
#define BTN_NEXT 26
#define LED_SUCCESS 16
#define LED_ERROR 17

MFRC522 rfid(SS_PIN, RST_PIN);
Adafruit_SSD1306 display(128, 64, &Wire, -1);

void setup() {
  Serial.begin(115200);
  SPI.begin(18, 19, 23, 5);
  rfid.PCD_Init();
  
  pinMode(BTN_CONFIRM, INPUT_PULLUP);
  pinMode(BTN_NEXT, INPUT_PULLUP);
  pinMode(LED_SUCCESS, OUTPUT);
  pinMode(LED_ERROR, OUTPUT);

  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(10, 25);
  display.println("CHAKRA-BHARAT");
  display.display();
}

void loop() {
  // Check Buttons
  if (digitalRead(BTN_CONFIRM) == LOW) {
    Serial.println("PLAYER=1;ACTION=BUTTON;ITEM=CONFIRM");
    delay(300);
  }
  if (digitalRead(BTN_NEXT) == LOW) {
    Serial.println("PLAYER=1;ACTION=BUTTON;ITEM=NEXT");
    delay(300);
  }

  // Check RFID
  if (rfid.PICC_IsNewCardPresent() && rfid.PICC_ReadCardSerial()) {
    String uid = "";
    for (byte i = 0; i < rfid.uid.size; i++) {
      uid += String(rfid.uid.uidByte[i], HEX);
    }
    Serial.print("PLAYER=1;ACTION=BUILD;UID=");
    Serial.println(uid);
    rfid.PICC_HaltA();
    delay(500);
  }

  // Read Software Feedback
  if (Serial.available()) {
    String msg = Serial.readStringUntil('\n');
    if (msg.indexOf("STATUS=SUCCESS") >= 0) {
      digitalWrite(LED_SUCCESS, HIGH);
      delay(200);
      digitalWrite(LED_SUCCESS, LOW);
    }
  }
}
```


---

## ✦ NEW in this merged build — Learn & Earn + Real Strategy Board

**Run:** `cd backend && npm start` → open http://localhost:3000  (Node 18+; `gcc` for C, `python3` for Python, `javac/java` for Java must be installed for the in-game compiler).

| Feature | Where |
| :--- | :--- |
| **Learn → Play → Evaluate → Tokens**, automatically before *every* round, one player after another | `frontend/learn.js` |
| Class level (1–5 / 6–10 / 11–16) + 14 theme fields: Kids Learning, Alphabets, Colours, Fruits, Vegetables, Identification, C, Java, Python, IoT/Electronics, Mechanical, Robotics, Science, Mathematics | `learn.js` → `F` |
| Easy = MCQs · Normal = MCQs + code snippet · Difficult = code only (coding fields) / full MCQ set | `learn.js` |
| Built-in compiler for C, Java, Python (hidden-test submit) | `POST /api/run` in `backend/server.js` |
| Tokens → resources on the player dashboard (`POST /api/tokens/award`) | server + dashboard |
| 2 new resources: **Spices 🌶️** (trade routes) and **Knowledge 📚** (earned by learning) | `resources.js`, `game.html` |
| Commander Actions: **BUILD removed** (build by tapping a glowing ＋ hex on the board); **YAJNA → FOOD** with an Indian thali image (Annadanam: −1 Food, +1 Water, +2 Culture) | `game.html`, `gameEngine.js` |
| Strategy board moved to the **bottom** and redrawn as a real tabletop board (map hexes, rivers, player mats, buildings/events legends, turn order, score bar) | `frontend/board.js` |
| After all rounds: LIME explanation of the civilization scores **and** a Learn & Earn review per player (why answers were right/wrong) | `result.html`, `learn.js` |

---

## New in this build
- **Home page** is now the first screen (Play Now, Watch How To Play, Rules). 🏠 HOME is always in the top bar.
- **How-to-play video** (`frontend/assets/video/how_to_play.mp4`, 48 s) opens from Home, the top bar and the Start page. Replace the file with your own recording any time.
- **Languages in the compiler:** C, C++, Java, Python, JavaScript (learning content) plus Go, PHP and Ruby on the server (`POST /api/run`). `GET /api/languages` shows which compilers your machine has.
- **Score-based rewards:** tokens = correct answers × difficulty (×1/×2/×3) + score bonus (+1 at 60%, +2 at 80%) + perfect-run bonus (+3). Tokens are paid out as Food, Water, Materials, Wealth, Spices and Knowledge.

## Compiler troubleshooting
- **No gcc / g++ installed?** No problem: C and C++ now run on a **built-in engine** automatically (variables, arrays, pointers to variables, functions, recursion, loops, switch, printf/scanf, cout/cin, string, vector). Structs, malloc and file I/O need a real compiler (MinGW-w64 or MSYS2 on Windows).
- **Python / Java / Go / PHP / Ruby** use whatever is installed on your PC. If one is missing the game says so in plain words instead of a raw error. JavaScript always works.
- `GET /api/languages` reports what is available.

## Extra fun
Combo streaks (+1 token every 3 correct answers in a row), lightning answers (+1 token for two MCQs answered in under 8 seconds), score bonuses, confetti and sounds.
