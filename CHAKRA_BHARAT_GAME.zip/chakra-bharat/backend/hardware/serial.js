/**
 * CHAKRA-BHARAT: Hardware Communication Layer
 * Handles serial communication with ESP32 microcontroller over USB/UART
 * and provides seamless Virtual Hardware Simulation mode.
 *
 * Hardware Specification:
 * - Microcontroller: ESP32
 * - RFID Reader: MFRC522 (SPI: SS=5, SCK=18, MOSI=23, MISO=19, RST=14)
 * - OLED Display: 0.96" I2C SSD1306 (SDA=21, SCL=22)
 * - Push Buttons: CONFIRM=GPIO25, NEXT=GPIO26, EVENT=GPIO27
 * - Indicator LEDs: SUCCESS=GPIO16, ERROR=GPIO17, WS2812B=GPIO4
 * - Buzzer: GPIO33
 *
 * Protocol:
 * HW -> SW: PLAYER=1;ACTION=BUILD;ITEM=WATER_SYSTEM\n
 * SW -> HW: STATUS=SUCCESS;ITEM=WATER_SYSTEM;OLED=WATER BUILT\n
 */

const EventEmitter = require('events');

class HardwareManager extends EventEmitter {
  constructor(gameEngine = null) {
    super();
    this.gameEngine = gameEngine;
    this.serialPort = null;
    this.isConnected = false;
    this.portName = null;
    this.baudRate = 115200;
    this.mode = 'VIRTUAL'; // 'SERIAL' | 'VIRTUAL'

    // Telemetry state for Smart Board Monitor
    this.telemetry = {
      esp32: { connected: false, port: null, baud: 115200 },
      rfid: { active: true, lastScan: 'None', lastUid: null },
      oled: { line1: 'CHAKRA-BHARAT', line2: 'READY TO PLAY' },
      buttons: { confirm: false, next: false, event: false },
      leds: { success: false, error: false, status: 'IDLE' },
      buzzer: { state: 'OFF' },
      lastAction: { player: null, action: null, item: null, timestamp: null },
      lastResponse: { status: 'READY', message: 'System initialized in Virtual Mode' }
    };

    this.rxBuffer = '';
  }

  setGameEngine(gameEngine) {
    this.gameEngine = gameEngine;
  }

  /**
   * Parse incoming string protocol:
   * "PLAYER=1;ACTION=BUILD;ITEM=WATER_SYSTEM"
   */
  static parseMessage(rawLine) {
    if (!rawLine || typeof rawLine !== 'string') return null;
    const clean = rawLine.trim();
    if (!clean) return null;

    const parts = clean.split(';');
    const result = {};

    for (const part of parts) {
      const idx = part.indexOf('=');
      if (idx !== -1) {
        const key = part.slice(0, idx).trim().toUpperCase();
        const value = part.slice(idx + 1).trim();
        if (key === 'PLAYER') {
          result.player = parseInt(value, 10);
        } else if (key === 'ACTION') {
          result.action = value.toUpperCase();
        } else if (key === 'ITEM') {
          result.item = value.toUpperCase();
        } else if (key === 'UID') {
          result.uid = value.toUpperCase();
        } else {
          result[key.toLowerCase()] = value;
        }
      }
    }

    if (!result.action) {
      return null;
    }

    return result;
  }

  /**
   * Format outbound command to ESP32:
   * { status: "SUCCESS", item: "WATER_SYSTEM", oled: "WATER BUILT" }
   * -> "STATUS=SUCCESS;ITEM=WATER_SYSTEM;OLED=WATER BUILT\n"
   */
  static formatMessage(data) {
    const segments = [];
    for (const [key, value] of Object.entries(data)) {
      if (value !== undefined && value !== null) {
        segments.push(`${key.toUpperCase()}=${value}`);
      }
    }
    return segments.join(';') + '\n';
  }

  /**
   * Attempt to connect to a real serial port.
   * Gracefully falls back to Virtual Hardware Mode if unavailable.
   */
  async initSerial(preferredPort = null) {
    let SerialPort = null;
    try {
      // Dynamic require so missing native module never crashes the server
      const spModule = require('serialport');
      SerialPort = spModule.SerialPort || spModule;
    } catch {
      console.log('[Hardware] serialport module not installed. Running in Virtual Hardware Mode.');
      this.mode = 'VIRTUAL';
      this.isConnected = false;
      this.telemetry.esp32.connected = false;
      this.emit('status', this.getStatus());
      return false;
    }

    try {
      const ports = await SerialPort.list();
      console.log(`[Hardware] Available ports:`, ports.map(p => p.path));

      const targetPort = preferredPort || (ports.length > 0 ? ports[0].path : null);
      if (!targetPort) {
        console.log('[Hardware] No physical serial ports detected. Running in Virtual Hardware Mode.');
        this.mode = 'VIRTUAL';
        this.isConnected = false;
        this.telemetry.esp32.connected = false;
        this.emit('status', this.getStatus());
        return false;
      }

      this.serialPort = new SerialPort({
        path: targetPort,
        baudRate: this.baudRate,
        autoOpen: true
      });

      this.serialPort.on('open', () => {
        this.isConnected = true;
        this.mode = 'SERIAL';
        this.portName = targetPort;
        this.telemetry.esp32.connected = true;
        this.telemetry.esp32.port = targetPort;
        console.log(`[Hardware] Successfully connected to ESP32 on ${targetPort}`);
        this.sendToHardware({ status: 'CONNECTED', message: 'CHAKRA-BHARAT READY' });
        this.emit('status', this.getStatus());
      });

      this.serialPort.on('data', chunk => {
        this.rxBuffer += chunk.toString();
        let newlineIndex;
        while ((newlineIndex = this.rxBuffer.indexOf('\n')) !== -1) {
          const line = this.rxBuffer.slice(0, newlineIndex).trim();
          this.rxBuffer = this.rxBuffer.slice(newlineIndex + 1);
          if (line) {
            this.handleIncomingRawLine(line);
          }
        }
      });

      this.serialPort.on('close', () => {
        console.log('[Hardware] Serial connection closed. Switching to Virtual Mode.');
        this.isConnected = false;
        this.mode = 'VIRTUAL';
        this.telemetry.esp32.connected = false;
        this.emit('status', this.getStatus());
      });

      this.serialPort.on('error', err => {
        console.warn(`[Hardware] Serial port error (${err.message}). Safe fallback to Virtual Mode.`);
        this.isConnected = false;
        this.mode = 'VIRTUAL';
        this.telemetry.esp32.connected = false;
        this.emit('status', this.getStatus());
      });

      return true;
    } catch (err) {
      console.warn(`[Hardware] Failed to initialize serial: ${err.message}. Running in Virtual Mode.`);
      this.mode = 'VIRTUAL';
      this.isConnected = false;
      this.telemetry.esp32.connected = false;
      return false;
    }
  }

  /**
   * Send command packet to real ESP32 if connected, and update local telemetry.
   */
  sendToHardware(data) {
    // Update local telemetry
    if (data.status === 'SUCCESS') {
      this.telemetry.leds.success = true;
      this.telemetry.leds.error = false;
      this.telemetry.leds.status = 'SUCCESS';
    } else if (data.status === 'ERROR') {
      this.telemetry.leds.success = false;
      this.telemetry.leds.error = true;
      this.telemetry.leds.status = 'ERROR';
    }

    if (data.oled || data.message) {
      this.telemetry.oled.line1 = data.title || 'CHAKRA-BHARAT';
      this.telemetry.oled.line2 = data.oled || data.message || '';
    }

    this.telemetry.lastResponse = { ...data, timestamp: new Date().toISOString() };

    const formatted = HardwareManager.formatMessage(data);

    if (this.isConnected && this.serialPort && this.serialPort.isOpen) {
      this.serialPort.write(formatted, err => {
        if (err) console.error('[Hardware] Serial write error:', err.message);
      });
    }

    this.emit('telemetry', this.telemetry);
  }

  /**
   * Process raw serial line
   */
  handleIncomingRawLine(rawLine) {
    console.log(`[Hardware RX] ${rawLine}`);
    const parsed = HardwareManager.parseMessage(rawLine);
    if (!parsed) {
      this.sendToHardware({ status: 'ERROR', message: 'INVALID_COMMAND' });
      return;
    }

    this.processCommand(parsed);
  }

  /**
   * Unified command processor used by BOTH real serial and Virtual Hardware Simulator.
   * Ensures 100% logic parity.
   */
  processCommand(cmd) {
    this.telemetry.lastAction = {
      player: cmd.player || 1,
      action: cmd.action,
      item: cmd.item || cmd.uid || null,
      timestamp: new Date().toISOString()
    };

    if (cmd.uid) {
      this.telemetry.rfid.lastUid = cmd.uid;
      this.telemetry.rfid.lastScan = cmd.item || cmd.uid;
    }

    if (!this.gameEngine) {
      this.sendToHardware({ status: 'ERROR', message: 'GAME_ENGINE_NOT_READY' });
      return { success: false, reason: 'Game Engine not attached' };
    }

    // Execute through Game Engine
    const result = this.gameEngine.handleHardwareCommand(cmd);

    if (result.success) {
      this.sendToHardware({
        status: 'SUCCESS',
        action: cmd.action,
        item: cmd.item || '',
        message: result.message || 'ACTION_SUCCESS',
        oled: `${cmd.action}: ${cmd.item || 'OK'}`
      });
    } else {
      this.sendToHardware({
        status: 'ERROR',
        action: cmd.action,
        message: result.reason || 'ACTION_FAILED',
        oled: `ERR: ${result.reason || 'FAIL'}`
      });
    }

    this.emit('telemetry', this.telemetry);
    return result;
  }

  /**
   * Virtual Hardware Simulation entry point (invoked from frontend or test suite)
   */
  simulateInput(input) {
    if (typeof input === 'string') {
      return this.handleIncomingRawLine(input);
    }
    return this.processCommand(input);
  }

  getStatus() {
    return {
      mode: this.mode,
      isConnected: this.isConnected,
      portName: this.portName,
      baudRate: this.baudRate,
      telemetry: this.telemetry
    };
  }
}

module.exports = HardwareManager;
