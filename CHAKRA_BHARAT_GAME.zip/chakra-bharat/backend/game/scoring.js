/**
 * CHAKRA-BHARAT: Scoring Manager
 * Calculates the authoritative 100-point score across 6 weighted categories:
 * 1. Development (25 pts)
 * 2. Resource Efficiency (20 pts)
 * 3. Cultural Development (15 pts)
 * 4. Sustainability (15 pts)
 * 5. Adaptability (15 pts)
 * 6. Trade (10 pts)
 * Total: 100 pts
 */

class ScoringManager {
  static WEIGHTS = {
    development: 25,
    resourceEfficiency: 20,
    culturalDevelopment: 15,
    sustainability: 15,
    adaptability: 15,
    trade: 10
  };

  /**
   * Calculate category scores and final score for a single player
   */
  static calculatePlayerScore(player) {
    const breakdown = {
      development: 0,
      resourceEfficiency: 0,
      culturalDevelopment: 0,
      sustainability: 0,
      adaptability: 0,
      trade: 0,
      total: 0
    };

    const b = player.buildings || {};
    const r = player.resources || {};
    const s = player.stats || {};

    // 1. DEVELOPMENT (Max 25)
    // 4 buildings * 5 pts = 20 pts. +5 bonus for all 4
    let builtCount = 0;
    if (b.FARM) builtCount++;
    if (b.WATER_SYSTEM) builtCount++;
    if (b.MARKET) builtCount++;
    if (b.FORT) builtCount++;

    breakdown.development = builtCount * 5;
    if (builtCount === 4) {
      breakdown.development += 5; // Master builder bonus
    }

    // 2. RESOURCE EFFICIENCY (Max 20)
    // Avoid total depletion (no resource at 0) = +6 pts
    const zeroResources = Object.values(r).filter(val => (val || 0) === 0).length;
    let efficiencyPts = 0;
    if (zeroResources === 0) {
      efficiencyPts += 6;
    } else if (zeroResources === 1) {
      efficiencyPts += 3;
    }

    // Resource volume score: reward balanced stockpile up to 14 pts
    const totalStockpile = (r.food || 0) + (r.water || 0) + (r.materials || 0) + (r.wealth || 0) + (r.spices || 0) + (r.knowledge || 0);
    efficiencyPts += Math.min(14, Math.floor(totalStockpile * 0.7));
    // Avoidable execution mistakes reduce efficiency. The penalty is capped
    // so one bad click never destroys an otherwise strong civilization.
    efficiencyPts -= Math.min(4, s.failedActions || 0);
    breakdown.resourceEfficiency = Math.max(0, Math.min(20, efficiencyPts));

    // 3. CULTURAL DEVELOPMENT (Max 15)
    // Earned through festivals and cultural harmony
    let culturalPts = Math.min(15, (player.scoreBreakdown?.culturalDevelopment || 0) + (s.festivalsCelebrated || 0) * 5);
    breakdown.culturalDevelopment = Math.min(15, culturalPts);

    // 4. SUSTAINABILITY (Max 15)
    // Water System = 10 pts; healthy water reserve buffer (water >= 3) = 5 pts
    let sustainabilityPts = 0;
    if (b.WATER_SYSTEM) {
      sustainabilityPts += 10;
    }
    if ((r.water || 0) >= 3) {
      sustainabilityPts += 5;
    } else if ((r.water || 0) >= 1) {
      sustainabilityPts += 2;
    }
    breakdown.sustainability = Math.min(15, sustainabilityPts);

    // 5. ADAPTABILITY (Max 15)
    // Successfully mitigating disasters (Drought, Flood, Shortage)
    let adaptabilityPts = 0;
    adaptabilityPts += (s.timesProtectedByWaterSystem || 0) * 6;
    if (b.FORT) adaptabilityPts += 4;
    adaptabilityPts += Math.min(5, (s.negativeEventsSurvived || 0) * 2);
    adaptabilityPts -= Math.min(4, (s.unprotectedCrises || 0) * 2);
    breakdown.adaptability = Math.max(0, Math.min(15, adaptabilityPts));

    // 6. TRADE (Max 10)
    // Market built = 5 pts; active trades / trade boom benefits = up to 5 pts
    let tradePts = 0;
    if (b.MARKET) tradePts += 5;
    tradePts += Math.min(5, (s.tradesCompleted || 0) * 2 + (s.timesBenefitedByMarket || 0) * 3);
    tradePts -= Math.min(2, s.failedTrades || 0);
    breakdown.trade = Math.max(0, Math.min(10, tradePts));

    // TOTAL
    breakdown.total = breakdown.development +
      breakdown.resourceEfficiency +
      breakdown.culturalDevelopment +
      breakdown.sustainability +
      breakdown.adaptability +
      breakdown.trade;

    player.score = breakdown.total;
    player.scoreBreakdown = breakdown;

    return breakdown;
  }

  /**
   * Calculate scores for all players, determine ranking and victory reasoning
   */
  static evaluateGame(players) {
    if (!players || players.length === 0) return null;

    players.forEach(p => {
      this.calculatePlayerScore(p);
      p.checkAchievements();
    });

    const ranked = [...players].sort((a, b) => b.score - a.score);
    const winner = ranked[0];

    // Generate victory rationale
    let victoryReason = 'balanced leadership and strategic foresight';
    const topCategory = Object.entries(winner.scoreBreakdown)
      .filter(([cat]) => cat !== 'total')
      .sort((a, b) => b[1] - a[1])[0];

    if (topCategory) {
      switch (topCategory[0]) {
        case 'sustainability':
          victoryReason = 'exemplary water conservation and drought resilience';
          break;
        case 'development':
          victoryReason = 'rapid physical infrastructure and complete settlement construction';
          break;
        case 'adaptability':
          victoryReason = 'mastery over natural disasters and dynamic crisis mitigation';
          break;
        case 'resourceEfficiency':
          victoryReason = 'flawless stockpile management and zero resource depletion';
          break;
        case 'trade':
          victoryReason = 'flourishing trade networks and market dominance';
          break;
        case 'culturalDevelopment':
          victoryReason = 'rich cultural vitality and civic harmony';
          break;
      }
    }

    return {
      winner,
      victoryReason,
      rankings: ranked.map((p, idx) => ({
        rank: idx + 1,
        player: p.toJSON(),
        isWinner: p.id === winner.id
      }))
    };
  }
}

module.exports = ScoringManager;
